---
name: getnote-tag
description: 查看得到大脑笔记已有标签，为笔记增加标签，或按真实标签 ID 安全删除非系统标签，避免覆盖或误删其他标签。
description_zh: 通过得到大脑 MCP 查看和添加笔记标签，按真实标签 ID 安全删除非系统标签。
description_en: Use when listing or adding GetNote note tags, or safely removing non-system tags by their actual tag IDs through MCP.
version: "1.1.2"
author: GetNote
---

# 得到大脑标签

标签能力通过笔记详情和三个写入 Tool 完成。笔记 ID、标签 ID 均按不透明字符串原样传递。

## 查看与新增

- 查看当前标签：先调用 `get_note`，只读取返回的真实标签集合。
- 新增标签：调用 `add_note_tags`，传 `note_id` 和非空 `tags[]`。这只新增用户指定标签，不能描述成替换全部标签。
- 需要确认最终集合时，再调用一次 `get_note`，不要根据请求参数猜测结果。

## 删除与替换

- 删除前先调用 `get_note`，从结果中找到目标标签真实 `tag_id`，确认它不是系统标签，再调用 `delete_note_tag`。
- 用户只给标签名称时，不能把名称直接当 `tag_id`；同名或类型不明确时让用户选择。
- 删除标签属于破坏性变更，执行前取得用户明确确认。
- 用户要求替换全部标签时，先展示当前标签及将被移除的内容，确认后才调用 `update_note` 的 `tags[]`；不要用新增/逐个删除偷偷模拟未确认的覆盖。

只有 Tool 明确成功后才能说明标签已更新。标签不存在、系统标签、笔记不存在或权限不足时，说明真实原因并保留 `request_id`，不能降级成“已处理”。
