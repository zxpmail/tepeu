# 知识库 (wiki) 命令参考

## 查询命令帮助

当你不确定某个命令的具体参数、格式或可选项时，**优先执行 `--help` 查询**，不要猜测参数名或凭记忆编造。

```bash
# 查看 wiki 下所有子命令
dws wiki --help

# 查看具体命令的完整参数说明
dws wiki space get --help
dws wiki member add --help

# 查看子命令组下的所有命令
dws wiki space --help
dws wiki node --help
dws wiki member --help
```

规则：
- 参数名不确定时 → 先 `--help`，再调用
- 报错 "unknown flag" 时 → `--help` 确认正确的 flag 名称
- 不确定某个功能是否存在时 → `dws wiki --help` 查看命令列表

## 命令总览

### 创建知识库
```
Usage:
  dws wiki space create [flags]
Example:
  dws wiki space create --name "产品文档库" --format json
  dws wiki space create --name "技术方案" --desc "团队技术方案归档" --format json
Flags:
      --name string   知识库名称 (必填，不超过 100 字符)
      --desc string   知识库描述 (选填，不超过 500 字符)
      --icon string   知识库图标标识 (选填)
```

### 删除知识库

> **CAUTION:** 不可逆操作 — 执行前必须向用户确认。

```
Usage:
  dws wiki space delete [flags]
Example:
  dws wiki space delete --workspace <workspaceId>
  dws wiki space delete --workspace "https://alidocs.dingtalk.com/i/spaces/xxx/overview"
Flags:
      --workspace string   知识库 ID 或 URL (必填)
```

将指定知识库移入回收站。删除后知识库会进入回收站，可在回收站中恢复。

> **重要约束**：
> - 操作者必须具备知识库的 OWNER 角色。
> - 删除操作不可逆（从回收站恢复除外），请确认后再执行。

### 查看知识库详情
```
Usage:
  dws wiki space get [flags]
Example:
  dws wiki space get --workspace <workspaceId> --format json
  dws wiki space get --workspace "https://alidocs.dingtalk.com/i/spaces/xxx/overview" --format json
Flags:
      --workspace string   知识库 ID 或 URL (必填)
```

支持传入知识库 ID 或知识库 URL，系统自动识别。
知识库 URL 格式：`https://alidocs.dingtalk.com/i/spaces/{workspaceId}/overview`

### 列出空间（知识库 / 钉盘空间）
```
Usage:
  dws wiki space list [flags]
Example:
  dws wiki space list --format json                       # 组织知识库（默认）
  dws wiki space list --type myWikiSpace --format json    # 我的文档
  dws wiki space list --type orgSpace --format json       # 钉盘企业空间
  dws wiki space list --type mySpace --format json        # 钉盘「我的文件」
  dws wiki space list --type orgWikiSpace --limit 50 --format json
Flags:
      --type string    空间类型:
                         orgWikiSpace (默认) — 组织知识库
                         myWikiSpace — 我的文档个人空间
                         orgSpace — 钉盘企业空间
                         mySpace — 钉盘「我的文件」
      --limit string   每页数量 1-50 (默认 20)
      --cursor string  分页游标 (首页留空)
```

- `myWikiSpace`：返回当前用户的「我的文档」个人空间（固定 1 条，不支持分页）
- `orgWikiSpace`（默认）：返回组织内有权访问的知识库列表，支持分页
- 钉盘空间类型（`orgSpace` / `mySpace`）会自动路由到钉盘服务，等同于原 `drive list-spaces`（已 deprecated）

### 搜索知识库
```
Usage:
  dws wiki space search [flags]
Example:
  dws wiki space search --query "产品文档" --format json
  dws wiki space search --query "技术方案" --limit 20 --format json
  dws wiki space search --type myWikiSpace --format json
Flags:
      --query string   搜索关键词 (搜索组织知识库时必填，--type myWikiSpace 时可省略)
      --type string    知识库类型: myWikiSpace 时直接返回「我的文档」，省略则搜索组织知识库
      --limit string   返回数量 1-20 (默认 10)
```

当 `--type myWikiSpace` 时，忽略 `--query`，直接返回「我的文档」个人空间。

### 添加知识库成员（容器级授权）
```
Usage:
  dws wiki member add [flags]
Example:
  dws wiki member add --workspace <WS_ID> --users uid1 --role READER
  dws wiki member add --workspace <WS_ID> --users uid1,uid2 --role EDITOR
  dws wiki member add --workspace "https://alidocs.dingtalk.com/i/spaces/<WS_ID>/overview" --users uid1 --role MANAGER
  dws wiki member add --workspace <WS_ID> --members '[{"type":"USER","id":"uid1","roleId":"READER","corpId":"xxx"},{"type":"DEPT","id":"deptId1","roleId":"EDITOR","corpId":"xxx"}]' --notify
  dws wiki member add --workspace <WS_ID> --members '[{"type":"CONVERSATION","id":"cidXXX","roleId":"READER"},{"type":"TAG","id":"tagId1","roleId":"EDITOR","corpId":"xxx"}]'
Flags:
      --workspace string   目标知识库 ID 或 URL (必填)
      --users string       被加入的用户 userId 列表，逗号分隔 (旧格式，单次最多 30 个)
      --role string        授予的角色 (旧格式必填，大小写不敏感): MANAGER (管理者) / EDITOR (可编辑) / DOWNLOADER (可下载) / READER (可阅读)
      --members string     成员列表 JSON 数组（新格式），支持 USER/DEPT/CONVERSATION/TAG 类型（TAG=角色组），与 --users 互斥
      --notify bool        是否通知被添加的成员 (仅 --members 新格式时生效，默认 false)
```

> **两种传参方式（互斥）**：
> - 旧格式：`--users` 传入逗号分隔的 userId 列表 + `--role` 指定统一角色（仅 USER 类型）
> - 新格式：`--members` 传入 JSON 数组，每个成员包含 `type`（USER/DEPT/CONVERSATION/TAG）、`id`、`roleId`（建议全大写），支持混合类型
>
> **成员类型说明**：
> - `USER` — 用户，id 为用户 userId，需携带 `corpId`（标识用户所属组织）
> - `DEPT` — 部门，id 为部门 ID，需携带 `corpId`（标识部门所属组织）
> - `CONVERSATION` — 群聊，id 为群聊 conversationId（cid 开头），无需 `corpId`
> - `TAG` — 角色标签（也称角色组），id 为角色标签 ID，需携带 `corpId`。当用户要求"添加角色组"或"添加角色标签"时使用此类型
>
> **❗ 重要约束**：
> - 角色枚举：MANAGER / EDITOR / DOWNLOADER / READER（OWNER 不可通过此接口添加，知识库创建者默认为所有者）。
> - 操作者须满足该知识库配置的权限管理最低角色要求（默认 MANAGER，可配置为 EDITOR 等），权限不足返回 `forbidden.accessDenied`。
> - 单次请求最多 30 个成员，超出请分批调用。
> - `--notify` 仅在新格式（`--members`）时生效，仅对 USER 和 CONVERSATION 类型成员发送通知（DEPT 和 TAG 不通知），默认 false；省略时不会向服务端发送该字段，需要通知请显式传 `--notify`。旧格式始终通知。
> - 「我的文档」(myWikiSpace) 是个人空间，**不支持容器级成员管理**；后端会直接拒绝。如果你的目标只是把某篇文档分享给别人，请改用 `dws drive permission add` 在节点级别授权。

### 移除知识库成员
```
Usage:
  dws wiki member remove [flags]
Example:
  dws wiki member remove --workspace <WS_ID> --users uid1
  dws wiki member remove --workspace <WS_ID> --users uid1,uid2
  dws wiki member remove --workspace <WS_ID> --members '[{"type":"USER","id":"uid1","corpId":"xxx"},{"type":"DEPT","id":"deptId1","corpId":"xxx"}]'
Flags:
      --workspace string   目标知识库 ID 或 URL (必填)
      --users string       被移除的用户 userId 列表，逗号分隔 (旧格式，单次最多 30 个)
      --members string     成员列表 JSON 数组（新格式），只需 type 和 id（USER/DEPT/TAG 还需 corpId），与 --users 互斥
```

> **两种传参方式（互斥）**：
> - 旧格式：`--users` 传入逗号分隔的 userId 列表（仅 USER 类型）
> - 新格式：`--members` 传入 JSON 数组，只需 `type` 和 `id`（USER/DEPT/TAG 还需 `corpId`），支持 USER/DEPT/CONVERSATION/TAG
>
> **成员类型说明**：
> - `USER` — 用户，id 为用户 userId，需携带 `corpId`
> - `DEPT` — 部门，id 为部门 ID，需携带 `corpId`
> - `CONVERSATION` — 群聊，id 为群聊 conversationId（cid 开头），无需 `corpId`
> - `TAG` — 角色标签（也称角色组），id 为角色标签 ID，需携带 `corpId`
>
> **重要约束**：
> - OWNER 角色不可通过此接口移除。
> - 操作者须满足该知识库配置的权限管理最低角色要求（默认 MANAGER，可配置为 EDITOR 等），权限不足返回 `forbidden.accessDenied`。
> - 单次请求最多 30 个成员，超出请分批调用。
> - 移除后相关成员将无法访问该知识库下的内容（除非通过节点级权限另行授权）。
> - 「我的文档」(myWikiSpace) 是个人空间，**不支持容器级成员管理**。

### 修改知识库成员角色
```
Usage:
  dws wiki member update [flags]
Example:
  dws wiki member update --workspace <WS_ID> --users uid1 --role EDITOR
  dws wiki member update --workspace <WS_ID> --users uid1,uid2 --role READER
  dws wiki member update --workspace <WS_ID> --members '[{"type":"USER","id":"uid1","roleId":"EDITOR","corpId":"xxx"}]' --notify=false
  dws wiki member update --workspace <WS_ID> --members '[{"type":"TAG","id":"tagId1","roleId":"READER","corpId":"xxx"}]'
Flags:
      --workspace string   目标知识库 ID 或 URL (必填)
      --users string       目标用户 userId 列表，逗号分隔 (旧格式，单次最多 30 个)
      --role string        新角色 (旧格式必填，大小写不敏感): MANAGER / EDITOR / DOWNLOADER / READER
      --members string     成员列表 JSON 数组（新格式），支持 USER/DEPT/CONVERSATION/TAG 类型（TAG=角色组），与 --users 互斥
      --notify bool        是否通知被变更的成员 (仅 --members 新格式时生效，默认 false)
```

> **两种传参方式（互斥）**：
> - 旧格式：`--users` 传入逗号分隔的 userId 列表 + `--role` 指定统一角色（仅 USER 类型）
> - 新格式：`--members` 传入 JSON 数组，每个成员携带独立 `roleId`
>
> **成员类型说明**：
> - `USER` — 用户，id 为用户 userId，需携带 `corpId`
> - `DEPT` — 部门，id 为部门 ID，需携带 `corpId`
> - `CONVERSATION` — 群聊，id 为群聊 conversationId（cid 开头），无需 `corpId`
> - `TAG` — 角色标签（也称角色组），id 为角色标签 ID，需携带 `corpId`
>
> **重要约束**：
> - OWNER 角色不可通过此接口变更。
> - 操作者须满足该知识库配置的权限管理最低角色要求（默认 MANAGER，可配置为 EDITOR 等），权限不足返回 `forbidden.accessDenied`。
> - 单次请求最多 30 个成员，超出请分批调用。
> - `--notify` 仅在新格式（`--members`）时生效，仅对 USER 和 CONVERSATION 类型成员发送通知（DEPT 和 TAG 不通知），默认 false。

### 列出知识库成员
```
Usage:
  dws wiki member list [flags]
Example:
  dws wiki member list --workspace <WS_ID>
  dws wiki member list --workspace <WS_ID> --limit 50
  dws wiki member list --workspace <WS_ID> --filter-role EDITOR
  dws wiki member list --workspace <WS_ID> --next-token <上次返回的 nextToken>
Flags:
      --workspace string     目标知识库 ID 或 URL (必填)
      --limit int            返回成员数上限，默认 30，最大 50
      --filter-role string   按角色过滤，逗号分隔: OWNER / MANAGER / EDITOR / DOWNLOADER / READER (选填)
      --next-token string    分页游标，首次不传，后续传入上一次返回的 nextToken (选填)
```

> 底层一次性返回全量成员后在内存中按 pageSize 分页；当 `hasMore` 为 true 时，传入 `--next-token` 即可获取下一页。
> 操作者须满足该知识库配置的权限管理最低角色要求，权限不足返回 `forbidden.accessDenied`。

> ⚠️ **返回字段限制**：`member list` 每条只返回 `name` / `role` / `type` 三个字段，**不含 userId**（服务端不返回）。因此**无法**从 `member list` 拿到 userId 再去串联 `member update` / `member remove`。要对某人改角色 / 移除，需另行拿到其 userId（例如用 `dws contact user search --query "<姓名>"` 按姓名反查）。

### 查询知识库动态
```
Usage:
  dws wiki feed list [flags]
Aliases:
  list, ls
Example:
  dws wiki feed list --workspace <workspaceId> --format json
  dws wiki feed list --workspace <workspaceId> --limit 10 --format json
  dws wiki feed list --workspace <workspaceId> --exclude-file --format json
  dws wiki feed list --workspace <workspaceId> --limit 10 --cursor <nextToken> --format json
Flags:
      --workspace string   知识库 ID 或 URL (必填)
      --limit int          每页数量 (默认 10，最大 20)。用户未明确要求条数时禁止加此 flag，让服务端走默认 10
      --cursor string      分页游标 (首页留空)
      --exclude-file       排除普通文件、媒体文件、文件夹及 Office 文件动态，仅保留在线文档操作 (默认 false)
```

查询指定知识库的动态，返回谁在什么时间进行了更新、上传、评论等操作。
支持传入知识库 ID 或知识库 URL，系统自动识别。
支持分页，通过 `--cursor` 传入上次返回的 nextToken 获取下一页；出参 `hasMore` 指示是否还有下一页。

> **权限要求**：调用者需具备知识库的成员权限，非成员会被拒绝访问。

**动态类型 `type` 枚举（严格按此映射展示，禁止猜测）**：

| type | 含义 |
|------|------|
| 0 | 创建文档 |
| 1 | 更新文档 |
| 2 | 评论文档 |
| 3 | 点赞文档 |
| 4 | 加入团队空间 |
| 5 | 表格选区数据变更 |
| 6 | 更新 office 文件 |
| 7 | 上传普通文件（非媒体文件） |
| 8 | 上传媒体文件（图片/视频） |
| 9 | 上传文件夹 |
| 10 | 上传文件夹 V2 |
| 11 | 加入团队 |
| 12 | 创建知识库 |

> **重要 — 展示规则（必须严格遵守）**：
> 1. **typeLabel 字段**：CLI 已自动将 `type` 数字映射为 `typeLabel` 中文标签（如 `更新文档`、`创建文档`），**直接使用 `typeLabel` 展示即可**，无需自行查表映射。
> 2. **timeFormatted 字段**：已是北京时间字符串（格式如 `2026-07-30 08:00`），直接展示即可，无需任何转换。原始毫秒时间戳保存在 `time` 字段中（数字类型）。

### 列出知识库节点
```
Usage:
  dws wiki node list [flags]
Aliases:
  list, ls
Example:
  dws wiki node list --workspace <workspaceId> --format json
  dws wiki node list --workspace <workspaceId> --folder <parentNodeId> --format json
  dws wiki node list --workspace <workspaceId> --limit 20 --cursor <pageToken> --format json
Flags:
      --workspace string   知识库 ID (必填)
      --folder string      父节点 nodeId (选填，不传则列出根目录)
      --limit int          每页数量 (默认 50，最大 50)
      --cursor string      分页游标
```

### 在知识库中创建节点
```
Usage:
  dws wiki node create [flags]
Example:
  dws wiki node create --workspace <workspaceId> --name "新文档" --format json
  dws wiki node create --workspace <workspaceId> --name "方案目录" --type folder --format json
  dws wiki node create --workspace <workspaceId> --name "数据表" --type axls --folder <parentNodeId> --format json
Flags:
      --workspace string   知识库 ID (必填)
      --name string        节点名称 (必填)
      --type string        节点类型 (默认 adoc)，实际支持: adoc(在线文档) / axls(在线表格) / appt(演示文稿) / adraw(白板) / amind(脑图) / able(多维表) / folder(文件夹)
      --folder string      父节点 nodeId (选填，不传则在根目录创建)
```

> ⚠️ **type 枚举修正**：`--help` 中列出的 `asheet` 会被后端拒绝，**不要使用**；创建在线表格请用 `axls`。实际可用类型以上方列表为准。

### 复制知识库节点
```
Usage:
  dws wiki node copy [flags]
Example:
  dws wiki node copy --workspace <workspaceId> --node <nodeId> --format json
  dws wiki node copy --workspace <workspaceId> --node <nodeId> --folder <targetFolderId> --format json
Flags:
      --workspace string   知识库 ID (必填)
      --node string        源节点 ID (必填)
      --folder string      目标文件夹 nodeId (选填)
```

### 移动知识库节点
```
Usage:
  dws wiki node move [flags]
Example:
  dws wiki node move --workspace <workspaceId> --node <nodeId> --folder <targetFolderId> --format json
  dws wiki node move --workspace <workspaceId> --node <nodeId> --format json
Flags:
      --workspace string   知识库 ID (必填)
      --node string        源节点 ID (必填)
      --folder string      目标文件夹 nodeId (选填)
```

### 删除知识库节点

> **CAUTION:** 不可逆操作 — 执行前必须向用户确认。

```
Usage:
  dws wiki node delete [flags]
Example:
  dws wiki node delete --workspace <workspaceId> --node <nodeId>
  dws wiki node delete --workspace <workspaceId> --node <nodeId> --yes
Flags:
      --workspace string   知识库 ID (必填，用于权限校验)
      --node string        节点 ID (必填)
```

将知识库中的节点移入回收站。权限要求: 对节点有"管理"权限。

### 在知识库中搜索节点
```
Usage:
  dws wiki node search [flags]
Example:
  dws wiki node search --workspace <workspaceId> --query "方案" --format json
  dws wiki node search --workspace <workspaceId> --query "周报" --limit 10 --format json
  dws wiki node search --workspace <workspaceId> --query "设计" --extensions adoc,axls --format json
Flags:
      --workspace string    知识库 ID (必填)
      --query string        搜索关键词 (必填)
      --extensions strings  按文件扩展名过滤，逗号分隔 (如 adoc,axls,pdf) (选填)
      --limit int           每页数量 (默认 10，最大 30) (选填)
      --cursor string       分页游标 (选填)
```

在指定知识库空间内搜索节点。与 `drive search` 的区别：
- `wiki node search` — 限定在某个知识库空间内搜索（需要 `--workspace`）
- `drive search` — 全局搜索，聚合钉盘 + 文档空间结果

### 设置知识库空间分享范围

设置整个知识库空间（WikiSpace）的分享范围（可见性）。本命令作用于整个知识库空间及其下所有未打断继承的节点，而非单个文档/文件夹。

> **`permission set-share-scope` 为 [危险] 操作，执行前需要向用户确认。确认后传入 `--yes` 跳过交互式确认。**

> **❗ PRIVATE 关闭不可逆**：会把空间下所有未打断继承的节点一并恢复为仅成员可见，且不保留各节点关闭前的原有档位；如需恢复公开必须重新设置。

```
Usage:
  dws wiki permission set-share-scope --workspace <ID> --visibility <PRIVATE|ORGANIZATION|PUBLIC> [flags]
Example:
  dws wiki permission set-share-scope --workspace WORKSPACE_ID --visibility ORGANIZATION --role READER
  dws wiki permission set-share-scope --workspace WORKSPACE_ID --visibility PUBLIC --role DOWNLOADER
  dws wiki permission set-share-scope --workspace WORKSPACE_ID --visibility PRIVATE
Flags:
      --workspace string    目标知识库 ID 或 URL (必填)
      --visibility string   目标可见性: PRIVATE / ORGANIZATION / PUBLIC (必填)
      --role string         链接访问者默认角色: READER / DOWNLOADER / EDITOR（PUBLIC 仅 READER/DOWNLOADER）(选填)
      --partner             企业内公开是否包含合作伙伴（外包）(选填，仅 ORGANIZATION)
      --can-search          是否可被组织内搜索 (选填，仅 ORGANIZATION)
      --can-recommend       是否可被组织内推荐 (选填，仅 ORGANIZATION)
```

三档语义：
- `PRIVATE` — 仅空间成员可访问（关闭企业内公开/互联网公开）。无需其他参数。
- `ORGANIZATION` — 企业内公开：企业内所有成员可访问。可附带 `--role`、`--partner`、`--can-search`、`--can-recommend`。
- `PUBLIC` — 互联网公开：互联网上任何人可访问（全库爆炸半径）。`--role` 仅接受 READER/DOWNLOADER（传 EDITOR 本地拒绝）；空间级不支持密码保护与有效期设置。

档位×参数适用矩阵：

| 档位 | --role | --partner | --can-search | --can-recommend | --password | --expire-days |
|------|--------|-----------|--------------|-----------------|------------|---------------|
| PRIVATE | ✖ | ✖ | ✖ | ✖ | ✖ | ✖ |
| ORGANIZATION | ✔ | ✔ | ✔ | ✔ | ✖ | ✖ |
| PUBLIC | ✔（仅 READER/DOWNLOADER） | ✖ | ✖ | ✖ | ✖ | ✖ |

不适用组合本地拒绝（exit 3）。

部分更新语义：可选参数不传即不下发、保持原值不变。布尔三态（`--partner`/`--can-search`/`--can-recommend`）：未设不下发，显式 `--xxx=false` 也会下发。只传 `--can-search` 或 `--can-recommend` 其一时，另一项由服务端联动跟随同值。

操作者必须具备知识库的 MANAGER 或 OWNER 角色，否则返回 `forbidden.accessDenied`。当组织开启公开分享审批策略时，PUBLIC 可能进入待审批状态（`pendingApproval=true`）。

返回体已回显写入后的 `visibility`/`defaultRole`/`partnerIncluded`/`canSearch`/`canRecommend`/`spaceUrl` 等字段，无需额外查询命令。

与其他命令的区分：
- 设置单个节点/文档/文件夹的分享范围 → `drive permission set-share-scope`（节点级）
- 管理知识库成员（添加/移除协作者） → `wiki member`，不要用分享范围
- 查询知识库详情 → `wiki space get`，但返回体不含完整分享范围字段

## 意图判断

- 用户说"创建知识库/新建知识库" → `space create`
- 用户说"查看知识库/知识库详情" → `space get`
- 用户说"我的知识库/知识库列表/有哪些知识库" → `space list`
- 用户说"列出钉盘空间/钉盘团队空间" → `space list --type orgSpace`
- 用户说"搜索知识库/找知识库" → `space search`
- 用户说"我的文档/个人空间" → `space list --type myWikiSpace`
- 用户说"知识库下的文件/知识库里有哪些文档/浏览知识库内容" → `node list`（需 `--workspace`）
- 用户说"在知识库里搜文档/空间内搜索" → `node search`（需 `--workspace` + `--query`）
- 用户说"在知识库里创建文档/新建文件夹" → `node create`（需 `--workspace` + `--name`）
- 用户说"复制知识库里的文档" → `node copy`（需 `--workspace` + `--node`）
- 用户说"移动知识库里的文档" → `node move`（需 `--workspace` + `--node`）
- 用户说"删除知识库里的文档/节点" → `node delete`（需 `--workspace` + `--node`）
- 用户说"把知识库分享给某人/给某人加入知识库/邀请进知识库" → `member add`（需 `--workspace` + `--users` + `--role`，或 `--workspace` + `--members`）
- 用户说"加成员并通知他/邀请后告知对方" → `member add --members ... --notify`；用户说"加进去但不要通知/悄悄加" → `member add --members ... --notify=false`
- 用户说"修改某人在知识库的权限/调整成员角色" → `member update`
- 用户说"移除知识库成员/把某人从知识库移除/删除知识库成员" → `member remove`（需 `--workspace` + `--users`）
- 用户说"知识库有哪些成员/查看知识库成员" → `member list`
- 用户说"知识库动态/最近有什么更新/谁改了什么/知识库活动" → `feed list`（需 `--workspace`）
- 用户说"知识库最近的评论/更新记录/操作日志" → `feed list`（需 `--workspace`）
- 用户说"删除知识库/移除知识库/把知识库删了" → `space delete`（需 `--workspace`）
- 用户说"设置知识库分享范围/知识库可见性/知识库企业内公开/知识库互联网公开/空间分享范围/知识库可见范围" → `permission set-share-scope`（需 `--workspace` + `--visibility`）
- 用户说"排除文件/只看创建文档/只看更新文档/只看文档操作/不要上传文件的记录/过滤掉文件动态/只看文档变更" → `feed list --exclude-file`（**必须带 flag，禁止客户端自行过滤**）

> **重要 — `--exclude-file` 使用规则**：
> 当用户意图排除文件类动态（上传文件、更新 office 文件等）或只看文档操作时，**必须在命令中带上 `--exclude-file`**，由后端完成过滤。禁止先拉全量数据再用 Python/jq 等工具在客户端过滤，那样既浪费带宽又可能因分页遗漏数据。

> **通知意图 → `--notify`**（`--members` 新格式默认不通知，省略时 CLI 不向服务端发送该字段）：
> - 用户明确要求“通知 / 告知 / 提醒对方 / 让他知道” → 追加 `--notify`
> - 用户明确要求“不要通知 / 别提醒 / 悄悄加 / 不要打扰” → **必须改用 `--members` 并传 `--notify=false`**；旧格式 `--users` 始终通知且无法关闭，此时继续用旧格式会违背用户意图
> - 用户没提通知需求 → 走 `--members` 时**不传该 flag**，保持不通知；不要自行补上 `--notify`
> - 仅 USER 和 CONVERSATION 类型成员会收到通知；被授权对象是 DEPT / TAG 时通知不会送达，**需主动向用户说明这一点**，不要默不作声

> **跨产品路由说明**：知识库节点的**内容操作**（读取/编辑/块级操作）仍由 `dws doc` 承担：
>- 用户说"读某个知识库里的某篇文档" → 先 `node list` 拿到 nodeId，再走 **`dws doc read --node <nodeId>`**
>- 用户说"搜文件"（不指定空间） → 走 **`dws drive search`**（全局聚合搜索）

关键区分（两层模型）：
- **wiki node**（空间管理层：节点的列出/创建/复制/移动/删除/搜索）vs **doc**（内容层：读写/编辑/块级/评论/导出）vs **drive**（存储层：文件上传/下载/搜索/权限，不关心格式）
- **wiki node search**（空间内搜索，需 `--workspace`）vs **drive search**（全局搜索，聚合钉盘+文档空间）
- **wiki node create**（在空间中创建空文件实体）vs **doc create**（创建文档并写入内容）
- **wiki member**（容器级，授权整个知识库）vs **drive permission**（节点级，授权单篇文档）
  - 「我的文档」**只能用** `drive permission`，不能用 `wiki member`
- **wiki permission set-share-scope**（空间级分享范围）vs **drive permission set-share-scope**（节点级分享范围）
  - "设置整个知识库的可见性" → `wiki permission set-share-scope`；"设置某个文档/文件夹的可见性" → `drive permission set-share-scope`
- **wiki space list --type orgSpace/mySpace**（列出钉盘空间）vs **wiki space list**（默认列出知识库）

## 核心工作流

```bash
# 列出我有权访问的组织知识库
dws wiki space list --format json

# 获取「我的文档」个人空间
dws wiki space list --type myWikiSpace --format json

# 搜索知识库
dws wiki space search --query "产品" --format json

# 创建知识库
dws wiki space create --name "新项目文档" --desc "项目相关文档归档" --format json

# 查看知识库详情
dws wiki space get --workspace <workspaceId> --format json

# ── 工作流: 浏览知识库内容 ──

# 1. 获取知识库 ID
dws wiki space list --format json

# 2. 列出根目录节点
dws wiki node list --workspace <workspaceId> --format json

# 3. 进入子目录
dws wiki node list --workspace <workspaceId> --folder <parentNodeId> --format json

# 4. 读取文档内容（跨到 doc）
dws doc read --node <nodeId> --format json

# ── 工作流: 在知识库中创建文档 ──

# 1. 创建文档节点
dws wiki node create --workspace <workspaceId> --name "新方案" --format json

# 2. 创建文件夹
dws wiki node create --workspace <workspaceId> --name "方案归档" --type folder --format json

# 3. 在指定文件夹下创建
dws wiki node create --workspace <workspaceId> --name "子文档" --folder <parentNodeId> --format json

# ── 工作流: 在知识库中搜索 ──

# 在指定知识库内搜索
dws wiki node search --workspace <workspaceId> --query "方案" --format json

# 按文件类型过滤
dws wiki node search --workspace <workspaceId> --query "周报" --extensions adoc --format json

# ── 工作流: 列出钉盘空间 ──

# 列出钉盘企业空间
dws wiki space list --type orgSpace --format json

# 获取钉盘「我的文件」
dws wiki space list --type mySpace --format json

# ── 工作流: 复制/移动节点 ──

# 复制节点到另一个文件夹
dws wiki node copy --workspace <workspaceId> --node <nodeId> --folder <targetFolderId> --format json

# 移动节点到另一个文件夹
dws wiki node move --workspace <workspaceId> --node <nodeId> --folder <targetFolderId> --format json

# ── 工作流: 删除知识库节点 ──

# 删除节点（会要求确认）
dws wiki node delete --workspace <workspaceId> --node <nodeId>

# ── 工作流: 查询知识库动态 ──

# 1. 获取知识库 ID
dws wiki space list --format json

# 2. 查询知识库动态
dws wiki feed list --workspace <workspaceId> --format json

# 3. 排除文件动态，只看文档操作
dws wiki feed list --workspace <workspaceId> --exclude-file --format json

# 4. 翻页（cursor 取上一页返回的 nextToken）
dws wiki feed list --workspace <workspaceId> --cursor <nextToken> --format json

# ── 工作流: 给知识库加成员 ──

# 1. 先确认知识库 ID（避免授权到「我的文档」）
dws wiki space list --format json   # 注意：不要 --type myWikiSpace

# 2. 添加成员
dws wiki member add --workspace <WS_ID> --users <UID> --role EDITOR --format json

# 3. 查看当前成员
dws wiki member list --workspace <WS_ID> --format json

# ── 工作流: 移除知识库成员 ──

# 1. 查看当前成员（只返回 name/role/type，拿不到 userId）
dws wiki member list --workspace <WS_ID> --format json

# 2. 另行按姓名反查目标成员的 userId（member list 不返回 userId）
dws contact user search --query "<姓名>" --format json

# 3. 移除成员
dws wiki member remove --workspace <WS_ID> --users <UID> --format json

# ── 工作流: 删除知识库 ──

# 1. 确认知识库信息
dws wiki space get --workspace <workspaceId> --format json

# 2. 删除知识库
dws wiki space delete --workspace <workspaceId> --format json

# ── 工作流: 设置知识库分享范围 ──

# 1. 确认知识库信息
dws wiki space get --workspace <workspaceId> --format json

# 2. 设置企业内公开
dws wiki permission set-share-scope --workspace <workspaceId> --visibility ORGANIZATION --role READER --format json

# 3. 设置互联网公开
dws wiki permission set-share-scope --workspace <workspaceId> --visibility PUBLIC --role DOWNLOADER --format json
```

## 上下文传递表

| 操作 | 从返回中提取 | 用于 |
|------|-------------|------|
| `space create` | `workspaceId` | node list / member add 的 --workspace |
| `space list` | `workspaceId` | node list / member add 的 --workspace |
| `space search` | `workspaceId` | node list / member add 的 --workspace |
| `space get` | `spaceUrl` | 分享给用户 |
| `node list` | `nodeId` | node copy/move/delete 的 --node / `dws doc read` 的 --node |
| `node search` | `nodeId` | node copy/move/delete 的 --node / `dws doc read` 的 --node |
| `node create` | `nodeId` | node copy/move/delete 的 --node / `dws doc read` 的 --node |
| `feed list` | `nextToken` | feed list 的 --cursor（翻页，`hasMore` 为 true 时继续）|
| `member list` | `name` / `role` / `type`（**不含 userId**）| 仅用于查看成员名单；**无法**从这里取 userId 去串联 member update/remove，需另行按姓名反查 userId（如 `dws contact user search --query "<姓名>"`）|
| `permission set-share-scope` | `visibility` / `defaultRole` / `spaceUrl` | 确认写入结果，无需额外查询 |

## 相关产品

- [doc](./doc.md) — 内容层：文档读写/编辑/块级操作/评论/导出（仅对自研文档有意义）
- [drive](./drive.md) — 存储层：文件列出/搜索/上传/下载/复制/移动/重命名/删除/权限（不关心文件格式）
