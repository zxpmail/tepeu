插件层（Plugins）设计
--------------

在 AgentOS v6.0 微内核架构中，**插件层** 是承载所有可扩展业务能力的“应用层”，位于用户空间之下、Kernel 之上。插件通过 **ACI 标准协议** 与 ACI Host 交互，对外提供工具（L1）、资源（L2）、会话（L3）和质量评估（L4）能力。插件层设计的目标是：**安全隔离、动态加载、版本兼容、质量可度量**。

* * *

### 一、插件分类与运行模式

| 插件等级     | 来源         | 沙箱类型                | 资源限制                 | 质量要求   | 网络策略                 |
| -------- | ---------- | ------------------- | -------------------- | ------ | -------------------- |
| **官方插件** | AgentOS 官方 | 特权容器（Docker）        | 无硬上限（受租户配额）          | A 级    | 允许出站（受限）             |
| **认证插件** | 第三方认证厂商    | Docker（非特权）         | CPU ≤ 2 核，内存 ≤ 4GB   | B 级及以上 | 仅允许连接内核 ACI 端点       |
| **社区插件** | 社区开发者      | Firecracker microVM | CPU ≤ 0.5 核，内存 ≤ 1GB | C 级及以上 | egress-deny，仅 DNS 查询 |

每个插件实例运行在独立的容器/虚拟化环境中，插件之间、插件与内核之间通过 gRPC/HTTP 通信。

* * *

### 二、插件生命周期

插件生命周期由 **Plugin Manager（内核模块）** 统一管理，状态机如下：

text

Submitted → Validated → Resolved → Sandboxed → Deploying → Active → Disabled → Uninstalled
                       ↓            ↓            ↓
                    Rejected    Failed      Rollback

* **安装**：用户提交插件包 → 签名验证 → 依赖求解 → 安全扫描 → 资源分配 → 启动实例 → 健康检查 → 注册到 ACI Registry → Active

* **升级**：蓝绿模式（先启新版本，健康后切流量，停旧版本）

* **回滚**：回退到上一个健康版本

* **卸载**：释放资源，注销 ACI Registry，删除存储

* * *

### 三、插件开发规范

#### 3.1 插件包结构

text

my-plugin-1.0.0/
├── manifest.yaml          # 插件元数据（必需）
├── plugin                 # 二进制可执行文件（或入口脚本）
├── config/                # 默认配置文件（可选）
├── assets/                # 静态资源（可选）
└── signature.asc          # PGP 签名（必需）

#### 3.2 manifest.yaml 示例

yaml

apiVersion: agentos.plugin/v1
kind: Plugin
metadata:
  name: my-plugin
  version: 1.0.0
  publisher: acme-corp
  quality_level: B        # 自评等级（最终由质量引擎认证）
spec:
  provides:
    - layer: L1
      type: tool
      name: data-analyzer
      description: "分析 CSV 文件"
      endpoint: "grpc://localhost:9001"   # 插件启动后监听的地址
    - layer: L2
      type: resource
      uri_prefix: "vector://customers"
  requires:
    - layer: L1
      tool: knowledge-retrieval
      version: "^1.2.0"
      quality_level: ">= B"
  runtime:
    language: go
    sandbox: docker          # 可被内核覆盖（根据等级）
    resources:
      cpu: 1000m
      memory: 2Gi
      gpu: 0
  permissions:
    - allow_network: ["api.internal.com"]
    - allow_fs_read: ["/etc/config"]
  health_check:
    endpoint: "/health"
    interval_sec: 10
    timeout_sec: 2
    failure_threshold: 3

#### 3.3 插件实现要求

* **必须实现 ACI 协议**：至少实现所声明的 ACI 层的 gRPC 服务（如 L1 ToolServer、L2 ResourceServer 等）。

* **必须提供健康检查端点**：支持 HTTP `/health` 或 gRPC `HealthCheck`。

* **必须上报执行指标**：每个请求响应中携带可选的 `_quality` 字段（如延迟、置信度），或通过 Sidecar 上报。

* **必须遵守安全策略**：不越权访问内核接口、不进行恶意网络请求。

* * *

### 四、插件与 ACI Host 的交互协议

插件启动后，向 **ACI Host 的 Registry** 注册自己的端点。注册请求示例：

protobuf

message RegisterRequest {
  string plugin_name = 1;
  string version = 2;
  string tenant_id = 3;
  repeated ProvidedCapability capabilities = 4;
  string endpoint = 5;           // 插件 gRPC 地址
  map<string, string> metadata = 6;
}

Registry 返回租约（lease），插件需定期发送心跳（如每 10 秒）维持注册状态。

当 ACI Host 收到客户端请求（如 `tools/call`）时，它会：

1. 根据工具名称从本地缓存查找提供该能力的插件实例列表。

2. 向 Quality Engine 请求这些实例的实时评分和权重。

3. 选择最优实例，向其 gRPC 端点转发请求。

4. 将执行结果返回客户端，并异步上报指标到 Event Bus。

* * *

### 五、插件安全隔离实现

| 隔离维度          | 实现方式                                                    |
| ------------- | ------------------------------------------------------- |
| **进程隔离**      | 每个插件独立容器（Docker）或 microVM（Firecracker）                  |
| **网络隔离**      | K8s NetworkPolicy：社区插件仅允许访问 ACI Host 和内核的特定端口，禁止 egress |
| **资源限制**      | K8s ResourceQuota + cgroup（CPU、内存限制）                    |
| **文件系统**      | 只读根文件系统，仅挂载必要的配置目录                                      |
| **内核 API 访问** | 插件只能通过 ACI Host 调用内核能力，不能直接访问内核 gRPC 服务                 |
| **签名验证**      | Plugin Manager 在安装前校验 PGP 签名，防止恶意包                      |

* * *

### 六、插件市场与分发

* **官方市场**：`https://market.agentos.io` 提供插件搜索、下载、评分展示。

* **私有市场**：企业可部署内部市场（兼容 OCI Registry），插件包存储在内网。

* **安装命令**：`agentos plugin install my-plugin --version ^1.0 --source https://market.acme.com`

* **离线安装**：`agentos plugin install file:///opt/plugins/my-plugin-1.0.0.tar.gz`

* * *

### 七、插件质量评估与反馈

* **认证评估**：插件上架前必须通过 Quality Engine 的认证套件（功能、性能、安全、文档）。

* **运行时评估**：Quality Engine 持续收集插件执行指标（成功率、延迟、资源效率），结合用户反馈计算实时评分。

* **评分影响**：高评分插件获得更高路由权重和资源优先级；低评分插件可能被降权、限流甚至自动卸载。

* **开发者反馈**：插件开发者可通过 ACI L4 质量接口查询自身评分、归因分析、改进建议。

* * *

### 八、插件开发 SDK 支持

AgentOS 提供多语言 SDK，简化插件开发：

* **Go SDK**：`github.com/agentos/plugin-sdk-go`

* **Python SDK**：`agentos-plugin-sdk`

* **Java SDK**：`com.agentos:plugin-sdk`

SDK 功能：

* 自动生成 gRPC 服务骨架

* 封装注册、心跳、健康检查逻辑

* 提供指标上报辅助函数

* 内置本地测试框架

**最小示例（Go）**：

go

package main
import (
    "context"
    "github.com/agentos/plugin-sdk-go"
    pb "github.com/agentos/aci-l1-tool"
)
type myTool struct{}
func (t *myTool) CallTool(ctx context.Context, req *pb.CallToolRequest) (*pb.CallToolResponse, error) {
    // 业务逻辑
    return &pb.CallToolResponse{Result: "ok"}, nil
}
func main() {
    plugin := sdk.NewPlugin(&sdk.Config{
        Name:    "my-plugin",
        Version: "1.0.0",
        Capabilities: []sdk.Capability{
            {Layer: "L1", Type: "tool", Name: "data-analyzer"},
        },
    })
    plugin.RegisterTool(&myTool{})
    plugin.Run()
}

* * *

### 九、可观测性

* **Metrics**：每个插件实例暴露 Prometheus 指标（请求数、延迟、错误数），由 Service Mesh 采集。

* **Traces**：每个请求携带 `trace_id`，插件需在日志和响应中透传。

* **Audit**：插件的关键操作（启动、停止、升级、调用）由 ACI Host 写入审计日志。

* * *

### 十、总结

插件层设计遵循 **安全第一、质量驱动、生态开放** 原则，通过：

* **三级隔离**（官方/认证/社区）平衡安全与灵活性；

* **标准化 ACI 协议** 保证跨语言互操作；

* **质量引擎** 实现优胜劣汰；

* **丰富的 SDK** 降低开发门槛。

使得 AgentOS 能够像操作系统一样，动态、安全地承载各类 AI 能力和业务扩展。
