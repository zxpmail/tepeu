# ACI Server Registry 五服务协作关系

## 一、五个服务清单

| 序号  | 服务                   | 简称  | 核心职责                       |
| --- | -------------------- | --- | -------------------------- |
| 1   | ToolServer           | TS  | `tools/list`, `tools/call` |
| 2   | ResourceServer       | RS  | `resources/read`           |
| 3   | PromptServer         | PS  | `prompts/get`              |
| 4   | SamplingServer       | SS  | `sampling/create`          |
| 5   | AdminBootstrapServer | ABS | 引导初始化、注册恢复、紧急策略            |

## 二、协作全景图

```mermaid
flowchart TD
    ACIHost["ACI Host"]
    TS["TS ToolServer"]
    RS["RS ResourceServer"]
    PS["PS PromptServer"]
    SS["SS SamplingServer"]
    ABS["ABS AdminBootstrapServer"]
    CC["ConfigCenter"]
    EB["EventBus"]
    AL["AuditLog"]

    ABS -->|bootstrap/registry init| TS
    ABS -->|bootstrap/registry init| RS
    ABS -->|bootstrap/registry init| PS
    ABS -->|bootstrap/registry init| SS

    ACIHost --> TS
    ACIHost --> RS
    ACIHost --> PS
    ACIHost --> SS

    TS -->|audit events| EB
    RS -->|audit events| EB
    PS -->|audit events| EB
    SS -->|audit events| EB
    ABS -->|control events| EB

    EB --> AL
    TS --> CC
    RS --> CC
    PS --> CC
    SS --> CC
```

#### 1. 控制与引导层 —— ABS (AdminBootstrapServer)

* **角色**：它是系统的“上帝视角”或“启动器”。
* **流向**：`ABS -->|bootstrap/registry init| [TS, RS, PS, SS]`
* **功能解读**：
  * **统一初始化**：所有的功能服务器（Tool, Resource, Prompt, Sampling）不是孤立启动的，而是由 ABS 统一进行注册和初始化。这意味着 ABS 维护着整个系统的**服务注册表**。
  * **配置下发**：ABS 确保所有服务器在启动时加载正确的配置，防止“配置漂移”。
  * **控制权**：它是唯一向 `EventBus` 发送“控制事件”的节点，意味着它可以动态控制系统的运行状态（如暂停服务、热更新）。

#### 2. 交互与执行层 —— ACI Host & Functional Servers

这是业务发生的核心区域，采用了**星型拓扑结构**：

* **ACI Host (中央枢纽)**：
  
  * 它是用户的入口（如 IDE、Chat 界面）。
  * 它不直接管理底层细节，而是通过标准协议与四个功能服务器交互。
  * **职责分离**：Host 只需要关注如何调用能力，不需要关心能力是如何实现的。

* **四大功能服务器**：
  
  * **TS (ToolServer)**：负责“做”。执行代码、API 调用。
  * **RS (ResourceServer)**：负责“读”。提供文件、数据库上下文。
  * **PS (PromptServer)**：负责“说”。提供标准化的提示词模板。
  * **SS (SamplingServer)**：负责“想”。处理复杂的推理任务，可能涉及反向代理 LLM 请求。

#### 3. 配置管理层 —— CC (ConfigCenter)

* **流向**：`[TS, RS, PS, SS] --> CC`
* **功能解读**：
  * **配置拉取/上报**：所有功能服务器都连接配置中心。这通常意味着它们会从这里拉取运行时配置（如 API 密钥、超时设置、模型参数），或者上报自身的元数据。
  * **动态更新**：如果管理员在 CC 修改了配置，TS/RS 等服务器可以实时感知并生效，无需重启服务。

#### 4. 可观测性与审计层 —— EB (EventBus) & AL (AuditLog)

* **流向**：`[TS, RS, PS, SS, ABS] --> EB --> AL`

* **功能解读**：
  
  * **全链路审计**：这是企业级应用最关键的部分。所有的操作（用户调用了工具、AI 读取了资源、ABS 下发了控制指令）都被转化为“事件”发送到总线。
  * **异步解耦**：功能服务器不需要等待日志写入磁盘，只需将事件推送到 `EventBus`（如 Kafka, Redis Pub/Sub），由 `AuditLog` 服务异步消费并持久化。
  * **安全合规**：所有的 AI 行为都被记录在案，用于事后追溯、安全分析或计费。 



## 三、典型流程

一个完整的用户指令（例如：“帮我优化这段代码”）是如何流转的？

1. **启动阶段 (Bootstrap)**
   
   * **ABS** 启动，初始化注册表。
   * **ABS** 唤醒并初始化 **TS, RS, PS, SS**，它们向 **CC** 拉取配置，并向 **ABS** 注册自己的能力。

2. **交互阶段 (Interaction)**
   
   * **ACI Host** 接收用户指令：“优化当前文件代码”。
   * **ACI Host** 询问 **RS** 获取当前文件内容（Resource）。
   * **ACI Host** 询问 **PS** 获取“代码优化”的标准提示词（Prompt）。
   * **ACI Host** 将代码和提示词组合，通过 **SS** 发送给 LLM 进行推理（Sampling）。
   * **ACI Host** 拿到优化后的代码，调用 **TS** 的“写入文件”工具（Tool）来保存结果。

3. **审计阶段 (Observability)**
   
   * 在上述每一步中，**RS, PS, SS, TS** 都会向 **EB** 发送审计事件（例如：“用户X读取了文件Y”，“用户X执行了写操作”）。
   * **EB** 将消息广播，**AL** 订阅并永久保存这些日志。
   * 如果操作违规，**ABS** 监听 **EB** 发现异常，可能会发送“控制事件”来阻断服务

## 四、依赖关系（有向）

| 调用方         | 被调用方         | 方式   | 说明     |
| ----------- | ------------ | ---- | ------ |
| ACI Host    | TS/RS/PS/SS  | gRPC | 标准协议调用 |
| ABS         | TS/RS/PS/SS  | 控制命令 | 引导与恢复  |
| TS/RS/PS/SS | ConfigCenter | 读取   | 读取服务策略 |
| 所有服务        | EventBus     | 异步发布 | 事件上报   |
| EventBus    | AuditLog     | 异步消费 | 审计写入   |

## 五、设计原则

- 协议统一：所有服务遵循 ACI 协议与统一错误码体系。
- 控制与数据分离：ABS 负责控制面，TS/RS/PS/SS 负责业务面。
- 事件驱动：关键状态变更统一事件化与审计化。
- 可降级：配置不可用、下游不可用时均具备降级路径。
