# AgentOS ACI Server Registry 设计文档索引

| 项目 | 内容 |
|------|------|
| 文档集版本 | v0.1 |
| 关联主文档 | `2026-04-14-agentos-v6-architecture.md` |
| 覆盖范围 | ACI Server Registry 5 个服务模块 |
| 目标 | 从协议蓝图落到可实施概要设计 |

## 模块文档清单

| 模块 | 文档 | 当前深度 |
|------|------|----------|
| ToolServer | `tool-server.md` | 概要设计（统一模板） |
| ResourceServer | `resource-server.md` | 概要设计（统一模板） |
| PromptServer | `prompt-server.md` | 概要设计（统一模板） |
| SamplingServer | `sampling-server.md` | 概要设计（统一模板） |
| AdminBootstrapServer | `admin-bootstrap-server.md` | 概要设计（统一模板） |

## 协作关系文档

- `module-collaboration.md`：五服务协作清单、全景图、典型流程、依赖矩阵、设计原则

## 统一概要模板

全部模块按同一章节组织：  
1) 模块概览 2) 职责边界 3) 核心实体 4) 生命周期状态 5) 核心机制  
6) 安全准入 7) 资源分配 8) 高可用 9) 接入/离线能力 10) 事件与审计  
11) 配置优先级 12) 可观测性 13) 关键错误码 14) 测试要求
