# ToolServer 设计-概要设计

| 项目 | 内容 |
|------|------|
| 版本 | v0.1 |
| 范围 | ACI Server Registry / ToolServer |
| 定位 | 工具发现与工具调用标准入口（L1） |

## 1. 模块概览
ToolServer 提供 `tools/list` 与 `tools/call` 能力，是 ACI L1 的核心交互面。
## 2. 职责边界
负责：工具注册索引、参数校验、调用转发、结果标准化。  
不负责：会话状态管理、评分计算、资源调度。
## 3. 核心实体
ToolDescriptor、ToolSchema、ToolCallRequest、ToolCallResult。
## 4. 生命周期状态
Registered -> Active -> Deprecated -> Disabled。
## 5. 核心机制
Schema 驱动参数校验 + 工具能力标签过滤。
## 6. 安全准入
按工具权限与租户策略校验调用资格。
## 7. 资源分配
调用执行资源由下游服务分配，ToolServer 仅控制面限流。
## 8. 高可用
无状态多副本 + 熔断重试。
## 9. 接入/离线能力
支持本地工具与远程工具适配。
## 10. 事件与审计
发布工具调用事件并写审计。
## 11. 配置优先级
API 参数 > 租户策略 > 全局策略 > 默认值。
## 12. 可观测性
调用时延、成功率、参数校验失败率。
## 13. 关键错误码
TS4001、TS4031、TS4041、TS5041。
## 14. 测试要求
覆盖 list/call 正常与异常路径，契约测试必过。
