# AdminBootstrapServer 设计-概要设计

| 项目 | 内容 |
|------|------|
| 版本 | v0.1 |
| 范围 | ACI Server Registry / AdminBootstrapServer |
| 定位 | 控制面引导、注册初始化、紧急策略下发 |

## 1. 模块概览
AdminBootstrapServer（原 Root Server 职责）负责控制面启动引导、服务注册初始化和紧急治理策略分发。
## 2. 职责边界
负责：引导初始化、注册表恢复、紧急策略广播。  
不负责：常规业务请求处理与推理执行。
## 3. 核心实体
BootstrapConfig、RegistrySnapshot、EmergencyPolicy、ControlCommand。
## 4. 生命周期状态
Bootstrapping -> Ready -> Degraded -> Emergency -> Recovering。
## 5. 核心机制
启动时加载注册快照，异常时下发紧急策略。
## 6. 安全准入
仅管理员与受信控制面可调用，强认证强审计。
## 7. 资源分配
控制面低频高可靠资源池，独立于数据面。
## 8. 高可用
多副本 + leader 选举，支持自动切换。
## 9. 接入/离线能力
支持离线恢复快照与灾备导入。
## 10. 事件与审计
引导、恢复、紧急动作必须写审计并发布事件。
## 11. 配置优先级
紧急策略 > 管理策略 > 全局配置 > 默认值。
## 12. 可观测性
启动耗时、恢复耗时、紧急切换次数。
## 13. 关键错误码
ABS4001、ABS4031、ABS5031、ABS5041。
## 14. 测试要求
覆盖引导、恢复、紧急切换、权限校验路径。
