# SamplingServer 设计-概要设计

| 项目 | 内容 |
|------|------|
| 版本 | v0.1 |
| 范围 | ACI Server Registry / SamplingServer |
| 定位 | 统一采样请求入口与采样策略管理（L2） |

## 1. 模块概览
SamplingServer 提供 `sampling/create` 能力，统一封装采样参数、模型路由与输出格式。
## 2. 职责边界
负责：采样请求参数校验、策略绑定、采样任务下发。  
不负责：模型推理执行（InferenceEngine 负责）。
## 3. 核心实体
SamplingRequest、SamplingPolicy、SamplingJob、SamplingResult。
## 4. 生命周期状态
Created -> Validated -> Dispatched -> Completed / Failed。
## 5. 核心机制
采样参数标准化（temperature/top_p/max_tokens）+ 策略约束。
## 6. 安全准入
按租户策略限制采样参数范围与模型可见性。
## 7. 资源分配
采样任务执行资源由 IE/RM 管理，SamplingServer 负责控制面节流。
## 8. 高可用
无状态多副本 + 请求幂等键保障。
## 9. 接入/离线能力
支持在线采样与离线批处理采样任务提交。
## 10. 事件与审计
采样任务创建、完成、失败均写审计并发布事件。
## 11. 配置优先级
请求参数 > 会话策略 > 租户策略 > 全局策略 > 默认值。
## 12. 可观测性
任务时延、成功率、参数越界拒绝率。
## 13. 关键错误码
SS4001、SS4031、SS4091、SS5041。
## 14. 测试要求
覆盖参数校验、策略约束、幂等重试路径。
