# ResourceServer 设计-概要设计

| 项目 | 内容 |
|------|------|
| 版本 | v0.1 |
| 范围 | ACI Server Registry / ResourceServer |
| 定位 | 语义资源读取与资源描述管理（L2） |

## 1. 模块概览
ResourceServer 提供 `resources/read` 等语义资源访问能力，统一资源命名与授权访问。
## 2. 职责边界
负责：资源目录、资源读取、版本与元信息管理。  
不负责：资源底层存储引擎实现、评分计算。
## 3. 核心实体
ResourceDescriptor、ResourceHandle、ResourceReadRequest、ResourceReadResult。
## 4. 生命周期状态
Registered -> Published -> Updated -> Deprecated。
## 5. 核心机制
按 URI 与 capability 标签寻址，支持分层缓存读取。
## 6. 安全准入
资源访问按租户与权限标签强校验。
## 7. 资源分配
读取缓存资源由 ResourceManager 配额控制。
## 8. 高可用
多副本目录服务 + 读缓存降级。
## 9. 接入/离线能力
支持本地文件、对象存储与离线包导入。
## 10. 事件与审计
资源读取与资源版本变更写入审计。
## 11. 配置优先级
请求参数 > 租户策略 > 全局策略 > 默认值。
## 12. 可观测性
读取延迟、命中率、权限拒绝率。
## 13. 关键错误码
RS4001、RS4031、RS4041、RS5031。
## 14. 测试要求
覆盖读权限、版本切换、缓存降级路径。
