# AgentOS Quality Engine 设计文档索引

| 项目 | 内容 |
|------|------|
| 文档集版本 | v0.1 |
| 关联主文档 | `2026-04-14-agentos-v6-architecture.md` |
| 覆盖范围 | Quality Engine 6 个子模块 |
| 目标 | 从评分能力蓝图落到可实施概要设计 |

## 子模块文档清单

| 子模块 | 文档 | 当前深度 |
|--------|------|----------|
| SuiteRegistry | `suite-registry.md` | 概要设计（统一模板） |
| BenchMark | `benchmark.md` | 概要设计（统一模板） |
| TaskExecutor | `task-executor.md` | 概要设计（统一模板） |
| MetricStore | `metric-store.md` | 概要设计（统一模板） |
| ReportEngine | `report-engine.md` | 概要设计（统一模板） |
| AnomalyAttribution | `anomaly-attribution.md` | 概要设计（统一模板） |

## 协作关系文档

- `module-collaboration.md`：六子模块协作清单、全景图、典型流程、依赖矩阵、设计原则

## 统一概要模板

全部子模块按同一章节组织：  
1) 模块概览 2) 职责边界 3) 核心实体 4) 生命周期状态 5) 核心机制  
6) 安全准入 7) 资源分配 8) 高可用 9) 接入/离线能力 10) 事件与审计  
11) 配置优先级 12) 可观测性 13) 错误码 14) 测试要求
