# TaskExecutor 设计-概要设计

| 项目 | 内容 |
|------|------|
| 版本 | v0.1 |
| 范围 | QualityEngine / TaskExecutor |
| 定位 | 评估任务调度、执行编排、结果回传 |

## 1. 模块概览
TaskExecutor 负责执行认证/运行时/客户自定义评估任务，并将结果写回 MetricStore 与 ReportEngine。

## 2. 职责边界
| 负责 | 不负责 |
|------|--------|
| 任务队列与优先级调度 | 评分融合算法 |
| 执行超时/重试控制 | 审计持久化 |
| 任务幂等与重放 | 配置发布 |
| 结果标准化输出 | 归因模型训练 |
| 失败补偿策略 | 资源调度算法 |

## 3. 核心实体
EvaluationTask、ExecutionPlan、ExecutionResult、RetryPolicy。

## 4. 生命周期状态机
Queued -> Dispatched -> Running -> Succeeded / Failed / Retrying / Cancelled。

## 5. 核心机制
- 按任务类型与优先级分队列执行。
- 失败任务按策略重试并输出失败原因。
- 支持幂等执行与回放。

## 6. 安全准入
任务执行前校验套件与租户权限。

## 7. 资源分配
调用 RM 申请评估执行资源，支持批量任务限流。

## 8. 高可用
任务持久化队列 + worker 无状态扩缩容。

## 9. 接入/离线能力
支持离线提交任务包与离线结果导入。

## 10. 事件与审计
发布 `qe.task.queued/running/succeeded/failed`。

## 11. 配置优先级
任务参数 > 套件策略 > 租户策略 > 默认值。

## 12. 可观测性
队列长度、执行时长、重试率、失败率。

## 13. 关键错误码
QETE4001、QETE4091、QETE5041。

## 14. 测试要求
覆盖任务调度、重试、取消、幂等执行。
