# Quality Engine 六子模块协作关系

## 一、六个子模块清单

| 序号  | 子模块                | 简称  | 核心职责             |
| --- | ------------------ | --- | ---------------- |
| 1   | SuiteRegistry      | SR  | 评估套件注册、版本管理、启停控制 |
| 2   | BenchMark          | BM  | 基准集管理、回放执行、基线对比  |
| 3   | TaskExecutor       | TE  | 评估任务调度、执行编排、结果回传 |
| 4   | MetricStore        | MS  | 指标存储、窗口聚合、查询服务   |
| 5   | ReportEngine       | RE  | 质量报告/趋势报告/合规报告生成 |
| 6   | AnomalyAttribution | AA  | 异常检测、根因归因、误报校正   |

## 二、协作全景图

```mermaid
flowchart TD
    subgraph qe [QualityEngine]
      SR["SR SuiteRegistry"]
      BM["BM BenchMark"]
      TE["TE TaskExecutor"]
      MS["MS MetricStore"]
      RE["RE ReportEngine"]
      AA["AA AnomalyAttribution"]
    end

    EB["EventBus"] -->|runtime_metrics/events| TE
    SR -->|suite config| TE
    TE -->|raw metrics| MS
    MS -->|aggregated features| AA
    MS -->|score inputs| RE
    AA -->|root_cause/anomaly_flags| RE
    BM -->|baseline compare result| RE
    BM -->|replay tasks| TE
    RE -->|quality reports| CC["ConfigCenter"]
    RE -->|report events| EB
    AA -->|anomaly events| EB
```

## 1. 任务调度与执行 —— TE

* **角色**：它是 QE 的“手脚”，负责具体的评估工作。
* **流向**：`EB -->|runtime_metrics/events| TE`，`SR -->|suite config| TE`
* **功能**：
  * **监听与触发**：它监听 `EventBus` 上的实时事件（如一次推理完成），或者根据 `SuiteRegistry` 中的配置（如“每天凌晨2点跑全量测试”）触发评估任务。
  * **任务回放**：它还支持 `replay tasks`，这意味着它可以重新执行历史任务（例如复现 Bug 或验证模型更新后的表现）。

#### 2. 数据存储与特征工程 —— MS

* **角色**：它是 QE 的“短期记忆”和“数据清洗工”。
* **流向**：`TE -->|raw metrics| MS`
* **功能**：
  * **原始数据接收**：接收 TE 采集的原始指标（如延迟、Token 数、准确率）。
  * **特征聚合**：它不只是存储，还会进行预处理。例如，将“过去 5 分钟的平均延迟”计算出来，作为特征提供给 AA 进行异常检测，或提供给 RE 进行评分。

#### 3. 智能分析与归因 —— AA

* **角色**：它是 QE 的“大脑”，负责侦探工作。
* **流向**：`MS -->|aggregated features| AA`
* **功能**：
  * **异常检测**：基于 MS 提供的特征，判断当前系统是否异常（例如：延迟突然飙升）。
  * **根因分析**：这是高级功能。它不仅告诉你“出错了”，还能通过关联分析告诉你“为什么出错”（例如：是因为显存不足，还是因为模型版本变更）。

#### 4. 基准测试与报告 —— BM & RE

* **角色**：它是 QE 的“裁判”和“发言人”。
* **流向**：`BM -->|baseline compare result| RE`
* **功能**：
  * **基准对比**：`BM` 负责将当前结果与“金标准”或“上一版本”进行对比。
  * **报告生成**：`RE` 汇总来自 MS 的分数、AA 的异常标记和 BM 的对比结果，生成最终的质量报告。
  * **策略反馈**：将报告写入 `ConfigCenter`，可能触发系统的自动熔断或降级。

## 三、典型协作流程

### 场景一：运行时评分更新

1. TE 从 EB 消费运行时指标事件并触发评估任务。
2. TE 执行后写入 MS。
3. MS 聚合窗口指标并输出给 RE。
4. RE 生成评分结果，写入 CC 并发布 `quality.score.updated`。

### 场景二：异常检测与归因

1. MS 将聚合特征输入 AA。
2. AA 判定异常并输出根因标签。
3. RE 合并评分与归因信息生成告警报告。
4. RE/AA 发布异常事件到 EB，供外部模块消费。

### 场景三：基线回放验证

1. BM 选择基准数据集并向 TE 下发回放任务。
2. TE 执行结果写入 MS。
3. BM 对比基线偏差并将结果传 RE。
4. RE 输出回归报告并同步 CC（仅策略建议，不直接改生产阈值）。

## 四、子模块依赖关系（有向）

| 调用方                | 被调用方               | 方式   | 说明          |
| ------------------ | ------------------ | ---- | ----------- |
| SuiteRegistry      | TaskExecutor       | 配置下发 | 下发可执行套件与版本  |
| BenchMark          | TaskExecutor       | 任务调用 | 触发回放任务      |
| TaskExecutor       | MetricStore        | 写入   | 写评估过程与结果指标  |
| MetricStore        | AnomalyAttribution | 数据读取 | 提供聚合特征      |
| MetricStore        | ReportEngine       | 数据读取 | 提供评分输入      |
| AnomalyAttribution | ReportEngine       | 结果传递 | 提供异常与根因信息   |
| ReportEngine       | ConfigCenter       | gRPC | 写入评分结果与建议   |
| ReportEngine       | EventBus           | 异步发布 | 发布报告与评分更新事件 |
| AnomalyAttribution | EventBus           | 异步发布 | 发布异常事件      |

## 五、设计原则总结

- 数据与执行分离：TE 负责执行，MS 负责存储聚合，职责清晰。
- 分析与展示分离：AA 负责判别归因，RE 负责报告输出。
- 基线独立：BM 负责回放与基线，不干扰在线主链路。
- 异步优先：事件统一经 EB 发布，降低模块耦合。
