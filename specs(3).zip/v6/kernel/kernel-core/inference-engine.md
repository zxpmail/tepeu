# Inference Engine 设计-概要设计

| 项目 | 内容 |
|------|------|
| 版本 | v0.1 |
| 范围 | Kernel Core / InferenceEngine |
| 定位 | 模型生命周期管理、会话执行、推理加速、质量特征输出 |

## 1. 模块概览

Inference Engine 是内核执行面核心，负责模型托管与推理服务，对外提供统一推理与会话能力，对内与资源管理、服务网格、质量引擎联动。

## 2. 职责边界

| 负责 | 不负责 |
|------|--------|
| 模型下载、校验、加载、预热、卸载 | 路由策略决策（ACI Host/QualityEngine） |
| 会话创建、上下文管理、checkpoint | 插件生命周期治理（PluginManager） |
| 推理执行与运行时剖面采集 | 审计存储（AuditLog 负责） |
| 推理异常恢复（OOM、实例不可用） | 资源调度算法（ResourceManager 负责） |
| 跨模型会话迁移能力 | 跨租户编排策略 |

## 3. 核心实体

| 实体 | 说明 |
|------|------|
| ModelArtifact | 模型版本、哈希、兼容标签 |
| InferenceSession | 会话状态、模型绑定、工具绑定 |
| RuntimeProfile | 时延、吞吐、错误率、缓存命中率 |
| CheckpointSnapshot | 会话恢复点 |

## 4. 生命周期状态机

主要状态：Downloaded → Verified → Loaded → Warmed → Serving → Draining → Unloaded / Failed。  
状态切换写入事件与审计流。

## 5. 推理执行

- 支持多轮会话、工具绑定、跨模型迁移。
- 支持批处理、前缀缓存与 KV 缓存。
- 默认超时阈值按模型等级配置，超时可重试或降级。

## 6. 安全准入

- 模型包校验：哈希/签名验证。
- 会话访问隔离：租户级上下文隔离。
- 工具调用约束：仅允许会话配置中的工具白名单。

## 7. 资源分配

Inference Engine 根据模型与会话负载生成资源需求，调用 `ResourceManager.Allocate` 获取租约。  
实例缩容与卸载触发资源释放与缓存回收。

## 8. 高可用与恢复

- 实例探活失败触发自动重启与流量切换。
- OOM 触发重启并按幂等策略重放请求。
- 模型热更新采用滚动方式，保障会话不中断或可恢复。

## 9. 模型来源与离线加载

- 支持在线模型仓库与离线模型目录（file://）。
- 支持企业私有模型仓库镜像。
- 自动更新仅通知，不默认自动切换生产版本。

## 10. 事件与审计

- 事件：`model.load.*`、`session.run.*`、`inference.fail.*`、`checkpoint.*`。
- 审计：关键操作包含 `trace_id`、`tenant_id`、`model_id`、`session_id`、`result`。

## 11. 配置覆盖优先级

`API 参数 > 会话策略 > 租户策略 > 全局配置 > 默认值`

## 12. 可观测性

- Metrics：推理时延、吞吐、错误率、缓存命中率、实例存活数。
- Traces：关键 span 包含 `bind_model`、`run_inference`、`cache_lookup`、`checkpoint`。

## 13. 关键错误码

| 错误码 | 含义 | 可重试 |
|--------|------|--------|
| IE4001 | 请求参数非法 | 否 |
| IE4031 | 会话越权访问 | 否 |
| IE4041 | 模型不存在 | 否 |
| IE5031 | 资源不足 | 是 |
| IE5041 | 推理超时 | 是 |

## 14. 测试要求

- 单元测试覆盖率 >= 85%。
- 集成测试覆盖全链路（Inference ↔ Resource ↔ Mesh ↔ QE）。
- 混沌测试验证实例故障、OOM、模型热更新下的恢复能力。
