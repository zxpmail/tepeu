# Plugin Manager 设计-概要设计

| 项目 | 内容 |
|------|------|
| 版本 | v0.1 |
| 范围 | Kernel Core / PluginManager |
| 定位 | 插件生命周期管理、依赖求解、安全准入、资源编排 |

## 1. 模块概览

Plugin Manager 负责将第三方或官方插件安全、稳定地接入 AgentOS 内核，并管理其运行状态。它对外提供统一的插件安装、升级、回滚、卸载能力，对内协调依赖求解器、安全扫描、资源管理器、ACI 注册表。

## 2. 职责边界

| 负责 | 不负责 |
|------|--------|
| 插件包签名校验、漏洞扫描 | 插件业务逻辑执行 |
| 依赖版本求解与冲突报告 | 插件运行时行为监控（SecurityBase 负责） |
| 插件生命周期状态机（安装/升级/回滚/禁用/卸载） | 资源调度算法（ResourceManager 负责） |
| 插件实例的资源申请与释放编排 | 插件间编排决策（编排引擎负责） |
| 插件多副本与故障迁移（配合 K8s） | 跨集群联邦调度 |

## 3. 核心实体

| 实体 | 说明 |
|------|------|
| PluginPackage | 插件包（含二进制、manifest、签名） |
| PluginManifest | 声明依赖、权限、运行时要求、质量等级 |
| PluginInstance | 运行中的插件实例（关联节点、资源租约） |
| DependencyGraph | 插件间依赖关系（版本约束） |

## 4. 生命周期状态机

主要状态：Submitted → Validated → Resolved → Sandboxed → Deploying → Active / Failed / Rollback / Disabled / Uninstalled。  
状态转换触发审计与事件发布。

## 5. 依赖求解

- 支持 SemVer 约束（`^1.2.3`、`~1.2`、`>=1.0 <2.0`）及质量等级约束（`quality_level >= B`）。
- 求解器基于 pubgrub 算法，输出有效版本组合或结构化冲突链。
- 求解超时阈值 500ms，超时直接失败。

## 6. 安全准入

- 签名验证：PGP 签名，官方内置公钥，支持离线缓存。
- 漏洞扫描：Trivy 扫描容器镜像与依赖库，高危漏洞（>=HIGH）阻断安装。
- 沙箱等级：根据插件等级（官方/认证/社区）分配不同隔离策略（特权容器/Docker/Firecracker）。

## 7. 资源分配

Plugin Manager 根据 manifest 生成 RuntimeSpec（CPU、内存、GPU、沙箱类型），调用 `ResourceManager.Allocate` 获取资源租约。  
资源释放由 PM 在卸载或回滚时主动触发，或由租约到期自动回收。

## 8. 多副本与高可用

- 支持配置副本数（`default_replicas`），滚动升级（先启新版本，再停旧版本）保障零停机。
- 故障迁移：节点宕机时 K8s 自动重新调度插件实例。
- 健康检查探活失败超过阈值则触发回滚或重启。

## 9. 插件市场与离线安装

- 市场协议：RESTful API，兼容 OCI Registry，插件包为 `.tar.gz`（含 manifest、镜像层、签名）。
- 离线安装：支持 `file://` 本地路径加载，企业可私有化部署市场。
- 自动更新检查：每天定时检查市场新版本，仅通知不自动升级。

## 10. 事件与审计

- 事件：通过 EventBus 发布生命周期事件（安装开始/成功/失败、升级、回滚、卸载）。
- 审计：所有状态变更必须写入审计日志，包含 `trace_id`、`tenant_id`、`plugin_name`、`version`、`actor`、`result`。

## 11. 配置覆盖优先级

`API 参数 > 租户策略 > 全局配置 > 默认值`

## 12. 可观测性

- Metrics：安装耗时、升级次数、回滚次数、求解耗时、活跃实例数、健康检查失败次数。
- Traces：每个生命周期操作生成包含 `resolve`、`scan`、`allocate`、`register`、`health_probe` 的 span。

## 13. 关键错误码

| 错误码 | 含义 | 可重试 |
|--------|------|--------|
| PM4001 | manifest 无效 | 否 |
| PM4091 | 依赖冲突 | 否 |
| PM4032 | 签名/扫描失败 | 否 |
| PM5031 | 资源不足 | 是 |
| PM5041 | 部署超时 | 是 |

## 14. 测试要求

- 单元测试覆盖率 >= 85%。
- 集成测试覆盖全链路（PM ↔ Resolver ↔ SecurityBase ↔ ResourceManager）。
- 混沌测试验证节点故障、网络分区下插件自动恢复。
