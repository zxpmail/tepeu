# AgentOS Kernel Core 设计文档索引

| 项目    | 内容                                      |
| ----- | --------------------------------------- |
| 文档集版本 | v0.2                                    |
| 关联主文档 | `2026-04-14-agentos-v6-architecture.md` |
| 覆盖范围  | Kernel Core 八大基础设施模块                    |
| 目标    | 从架构蓝图落到可实施设计输入                          |

## 模块文档清单

| 模块              | 文档                    | 当前深度       |
| --------------- | --------------------- | ---------- |
| ResourceManager | `resource-manager.md` | 概要设计（统一模板） |
| InferenceEngine | `inference-engine.md` | 概要设计（统一模板） |
| ServiceMesh     | `service-mesh.md`     | 概要设计（统一模板） |
| SecurityBase    | `security-base.md`    | 概要设计（统一模板） |
| PluginManager   | `plugin-manager.md`   | 概要设计（统一模板） |
| EventBus        | `event-bus.md`        | 概要设计（统一模板） |
| AuditLog        | `audit-log.md`        | 概要设计（统一模板） |
| ConfigCenter    | `config-center.md`    | 概要设计（统一模板） |

## 协作关系文档

- `module-collaboration.md`：八模块协作清单、全景图、典型流程、依赖矩阵、设计原则
- `kernel-userspace-plugin-collaboration.md`：Kernel 层与用户空间、插件层的协作机制
- 质量引擎独立文档集见：`../quality-engine/README.md`

## 统一概要模板

全部模块按同一章节组织：

1) 模块概览 2) 职责边界 3) 核心实体 4) 生命周期状态 5) 核心机制
2) 安全准入 7) 资源分配 8) 高可用 9) 接入/离线能力 10) 事件与审计
3) 配置优先级 12) 可观测性 13) 错误码 14) 测试要求

## 统一设计约束

- 接口优先：gRPC（控制路径）+ EventBus（异步路径）。
- 配置优先：策略由 ConfigCenter 下发，支持灰度和回滚。
- 审计优先：关键决策与变更必须写入 AuditLog。
- 安全优先：默认拒绝、最小权限、隔离运行。
- 可观测优先：metrics + traces + structured logs 全覆盖。
