# Kernel Core 八模块协作关系

## 一、八个模块清单

| 序号  | 模块               | 简称  | 核心职责                      |
| --- | ---------------- | --- | ------------------------- |
| 1   | Resource Manager | RM  | GPU/CPU/内存资源分配、调度、回收      |
| 2   | Inference Engine | IE  | 模型加载、推理执行、会话管理、KV Cache   |
| 3   | Quality Engine   | QE  | 插件/模型评分、多源验证、动态路由权重计算     |
| 4   | Security Base    | SB  | 认证授权、mTLS、沙箱隔离策略、安全审计     |
| 5   | Plugin Manager   | PM  | 插件安装、升级、回滚、依赖求解、生命周期管理    |
| 6   | Event Bus        | EB  | 异步事件发布/订阅（Kafka / gRPC 流） |
| 7   | Audit Log        | AL  | 不可变审计日志写入、查询、完整性校验        |
| 8   | Config Center    | CC  | 配置存储、动态下发、租户策略管理          |

## 二、模块协作全景图

说明：`QE` 为一个核心模块，内部包含 6 个子模块（SuiteRegistry、BenchMark、TaskExecutor、MetricStore、ReportEngine、AnomalyAttribution）。

```mermaid
flowchart TD
    ACIHost["ACI Host"]

    subgraph kernelCore [KernelCore]
      RM["RM ResourceManager"]
      IE["IE InferenceEngine"]
      QE["QE QualityEngine"]
      SB["SB SecurityBase"]
      PM["PM PluginManager"]
      EB["EB EventBus"]
      AL["AL AuditLog"]
      CC["CC ConfigCenter"]
    end

    ACIHost -->|install/upgrade| PM
    ACIHost -->|chat/infer| IE

    PM -->|gRPC allocate/release| RM
    PM -->|gRPC verify/scan| SB
    PM -->|read sandbox policy| CC
    PM -->|publish lifecycle| EB

    IE -->|gRPC allocate| RM
    IE -->|publish metrics| EB

    QE -->|consume metrics/events| EB
    QE -->|write score/route weights| CC

    RM -->|watch score/policy| CC
    SB -->|watch security policy| CC

    EB -->|consume| AL
    EB -->|consume| QE

    AL -->|read retention policy| CC
```

###### 1. 资源与生命周期管理 —— RM & PM

这是内核的“心脏”和“管家”。

* **PM (PluginManager)**：
  * **角色**：它是外部插件与内核的连接器。
  * **流向**：`ACIHost -->|install/upgrade| PM`
  * **功能**：负责处理 Host 发来的插件安装或升级请求。它不直接运行插件，而是协调资源。
* **RM (ResourceManager)**：
  * **角色**：它是内存、显存或计算槽位的“ allocator”。
  * **流向**：`PM -->|gRPC allocate/release| RM`，`IE -->|gRPC allocate| RM`
  * **功能**：通过 gRPC 高效地分配和释放资源。无论是插件加载需要内存，还是推理任务需要显存，都必须向 RM 申请。

#### 2. 推理与执行引擎 —— IE

这是内核的“肌肉”。

* **IE (InferenceEngine)**：
  * **角色**：实际执行 LLM 推理或计算任务的单元。
  * **流向**：`ACIHost -->|chat/infer| IE`
  * **功能**：接收 Host 的推理请求，向 RM 申请资源，执行计算，并上报指标。

#### 3. 智能调度与质量评估 —— QE

这是内核的“大脑”，负责优化系统性能。

* **QE (QualityEngine)**：
  * **角色**：系统的“自动驾驶仪”。
  * **流向**：`QE -->|write score/route weights| CC`
  * **功能**：它不直接处理业务，而是通过监听 `EventBus` 中的指标（如延迟、错误率、资源使用率），计算各个服务或路由的“健康分”或“权重”，并将这些策略写回 `ConfigCenter`。
  * **闭环控制**：`RM` 会根据 `CC` 中的分数来决定优先分配资源给谁，从而实现**自适应负载均衡**。

#### 4. 安全与审计 —— SB, EB & AL

这是内核的“免疫系统”和“黑匣子”。

* **SB (SecurityBase)**：
  
  * **角色**：安全守门员。
  * **流向**：`PM -->|gRPC verify/scan| SB`
  * **功能**：在插件安装或加载前，进行静态扫描和验证，确保没有恶意代码。

* **EB (EventBus) & AL (AuditLog)**：
  
  * **角色**：神经中枢与记忆体。
  * **流向**：`IE/PM -->|publish| EB -->|consume| AL`
  * **功能**：所有的生命周期事件（安装、分配）和运行指标（推理耗时）都通过 EB 广播。AL 负责持久化存储，用于事后审计。 

## 三、典型协作流程示例

### 场景一：安装并运行一个插件

1. 用户请求 -> ACI Host 调用 `PluginManager.InstallPlugin`。
2. PM 向 SB 请求签名验证和漏洞扫描。
3. PM 向 CC 获取租户级沙箱策略。
4. PM 调用 `ResourceManager.Allocate` 申请 CPU/内存/GPU。
5. RM 根据 QE 提供的评分权重（由 CC 下发）决定资源优先级并返回租约。
6. PM 启动插件实例并注册到 ACI Registry（ACI Host 组件，不在内核）。
7. PM 发布 `PluginInstallSucceeded` 到 EB。
8. AL 消费事件并写入审计日志。

### 场景二：推理请求与质量反馈闭环

1. 用户操作：用户在 `ACIHost` 发起对话 `chat/infer`。
2. 资源分配：`IE` 向 `RM` 申请显存资源。
3. 执行推理：`IE` 执行模型推理。
4. 指标上报：`IE` 发现本次推理延迟较高，向 `EB` 发布 `metrics: latency=500ms`。
5. 质量评估：`QE` 消费到该指标，计算出该模型实例的“健康分”下降。
6. 策略更新：`QE` 将新的低权重写入 `CC`。
7. 闭环生效：下一次请求到来时，`RM` 读取 `CC` 的策略，不再将流量分配给这个慢速实例，而是路由到更快的实例。

### 场景三：插件升级与回滚

1. PM 收到升级请求并调用内置 Resolver 求解依赖。
2. PM 通过 SB 扫描新版本安全风险。
3. PM 调用 RM 为新版本申请资源。
4. 新实例探活失败时，PM 从 CC 读取上一稳定配置并回滚。
5. PM 发布 `PluginUpgradeFailed` 到 EB。
6. AL 记录回滚；QE 可下调该插件评分。

### 场景四：安全策略变更

1. 管理员修改安全策略，CC 推送变更。
2. SB 监听策略并更新运行中插件约束（网络/沙箱）。
3. 若插件违规，SB 触发阻断并发布 `SecurityViolation`。
4. AL 记录事件；EB 通知 PM 可执行自动禁用。

## 四、模块间依赖关系（有向）

| 调用方              | 被调用方             | 调用方式         | 说明           |
| ---------------- | ---------------- | ------------ | ------------ |
| Plugin Manager   | Resource Manager | gRPC         | 申请/释放资源      |
| Plugin Manager   | Security Base    | gRPC         | 签名验证、漏洞扫描    |
| Inference Engine | Resource Manager | gRPC         | 获取推理资源       |
| Quality Engine   | Config Center    | gRPC / Watch | 读写评分、策略      |
| Resource Manager | Config Center    | Watch        | 监听评分变化       |
| Security Base    | Config Center    | Watch        | 监听安全策略       |
| 所有模块             | Event Bus        | 异步发布         | 发送事件         |
| Event Bus        | Audit Log        | 异步消费         | 写入审计日志       |
| Event Bus        | Quality Engine   | 异步消费         | 指标收集         |
| Audit Log        | Config Center    | 读取           | 获取审计策略（保留期等） |

## 五、设计原则总结

- 异步解耦：非关键路径（指标上报、审计）通过 EB 传递，避免阻塞主流程。
- 策略与机制分离：调度权重、安全规则、审计保留期由 CC 托管，模块动态生效。
- 可观测性优先：关键状态变更必须触发事件与审计，QE 基于数据驱动决策。
- 安全最小权限：SB 集中管理认证、沙箱、网络策略，其他模块通过 SB 执行安全动作。

通过以上协作机制，Kernel Core 八个模块可保持独立可测试性，同时形成高效协同闭环，支撑 AgentOS 作为企业级可部署系统运行。


