# Resource Manager 设计-概要设计

| 项目 | 内容 |
|------|------|
| 版本 | v0.1 |
| 范围 | Kernel Core / ResourceManager |
| 定位 | 资源抽象、调度分配、配额隔离、资源观测与回收 |

## 1. 模块概览

Resource Manager 负责将请求的逻辑资源需求转换为可执行的物理资源绑定，对外提供 Allocate/Release/WatchMetrics 能力，对内协调调度策略、配额控制与节点健康。

## 2. 职责边界

| 负责 | 不负责 |
|------|--------|
| CPU/GPU/内存分配、回收与租约管理 | 模型推理执行（InferenceEngine 负责） |
| 租户配额校验与隔离策略执行 | 质量评分计算（QualityEngine 负责） |
| 调度策略执行（质量优先/成本优先/实时保障） | 插件业务逻辑编排 |
| 资源事件上报与审计写入 | 业务可视化报表 |
| 故障节点剔除与重分配编排 | 跨集群联邦资源调度 |

## 3. 核心实体

| 实体 | 说明 |
|------|------|
| ResourceRequest | 资源申请请求（tenant/task/spec/priority/quality） |
| AllocationLease | 资源租约（绑定节点、资源明细、TTL） |
| TenantQuotaSnapshot | 租户资源配额快照 |
| NodeHealth | 节点可用性、压力与标签信息 |

## 4. 生命周期状态机

主要状态：Pending → Validating → Scheduling → Reserved → Bound → Active / Releasing / Released / Rejected / Reconcile。  
状态迁移触发审计与事件发布。

## 5. 调度与配额策略

- 支持 `quality-priority`、`cost-optimized`、`realtime-guarantee` 三类策略。
- 支持质量联动权重（A 级提升、C 级惩罚）。
- 配额策略按租户硬限制执行，超配额直接拒绝。
- 调度超时阈值 200ms，超时进入降级或失败返回。

## 6. 安全与隔离

- 租户级资源隔离：namespace + quota + network policy。
- 资源越权请求阻断并审计。
- 社区插件资源限制更严格（无 GPU 直通或经内核代理）。

## 7. 资源释放

Resource Manager 在任务完成、回滚、租约到期时执行释放：  
主动释放（调用 Release）+ 被动回收（TTL 到期）双路径并存。

## 8. 高可用与故障处理

- 节点故障：健康检查失败后剔除候选并触发重分配。
- 配置中心不可用：使用最近稳定快照只读运行。
- 质量引擎不可用：退化为静态调度权重。
- 回收失败：进入 Reconcile 队列补偿。

## 9. 部署与运行模式

- 控制面：Resource Manager 多副本部署（建议 >=3）。
- 数据面：资源节点通过 Agent 上报健康与可分配资源。
- 运行环境：K8s + cgroup/NUMA/MIG（按硬件能力开启）。

## 10. 事件与审计

- 事件：`resource.allocate.start/success/fail`、`resource.release.*`、`resource.preempt.*`。
- 审计：必须包含 `trace_id`、`tenant_id`、`task_id`、`lease_id`、`policy`、`result`。

## 11. 配置覆盖优先级

`API 参数 > 任务策略 > 租户策略 > 全局配置 > 默认值`

## 12. 可观测性

- Metrics：分配耗时、释放耗时、配额拒绝次数、抢占次数、节点健康度。
- Traces：每次分配包含 `validate`、`quota_check`、`schedule`、`lease_create` span。

## 13. 关键错误码

| 错误码 | 含义 | 可重试 |
|--------|------|--------|
| RM4001 | 资源请求参数非法 | 否 |
| RM4031 | 越权资源请求 | 否 |
| RM4091 | 超配额 | 否 |
| RM5031 | 资源不足 | 是 |
| RM5041 | 调度超时 | 是 |

## 14. 测试要求

- 单元测试覆盖率 >= 85%。
- 集成测试覆盖全链路（RM ↔ PM ↔ Inference ↔ Audit）。
- 混沌测试验证节点故障、配置中心不可用下的降级与恢复。
