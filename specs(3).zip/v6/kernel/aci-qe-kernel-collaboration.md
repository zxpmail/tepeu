# 在 AgentOS v6.0 架构中，**ACI Server Registry**（以下简称 Registry）位于 **ACI Host** 内部，属于“用户空间”组件；**Quality Engine** 和 **Kernel Core** 属于内核层。三者通过**服务发现 + 事件驱动 + 同步调用**协同工作，共同完成“能力注册 → 质量评分 → 路由决策 → 资源分配”的闭环。

* * *

### 一、组件职责划分

| 组件                      | 层级             | 核心职责                                               |
| ----------------------- | -------------- | -------------------------------------------------- |
| **ACI Server Registry** | 用户空间（ACI Host） | 插件/工具/资源服务器的**注册与发现**；维护端点列表（endpoint, 能力类型, 元数据）。 |
| **Quality Engine**      | 内核层            | 对插件进行**运行时评分**（基于成功率、延迟、用户反馈等）；提供评分查询接口。           |
| **Kernel Core**         | 内核层            | 提供底层资源管理（RM）、推理引擎（IE）、安全基座（SB）、配置中心（CC）等能力。        |

### 二、协作全景图

```mermaid
sequenceDiagram
    participant Plugin as 插件
    participant Registry as ACI Server Registry
    participant QE as Quality Engine
    participant Kernel as Kernel Core (RM/IE/CC)
    participant Client as 客户端请求

    Note over Plugin,Registry: 1. 注册阶段
    Plugin->>Registry: 注册(能力类型, 端点, 元数据)
    Registry->>Kernel: 请求分配资源(通过RM)
    Kernel-->>Registry: 返回租约
    Registry->>QE: 触发初次质量评估
    QE->>Kernel: 读取历史指标(从CC/AL)
    QE-->>Registry: 初始评分

    Note over Client,Registry: 2. 路由决策阶段
    Client->>Registry: 调用能力(如tools/call)
    Registry->>QE: 查询可用实例的实时评分
    QE-->>Registry: 返回(实例列表+评分+权重)
    Registry->>Kernel: 请求资源分配(择优)
    Kernel-->>Registry: 确认
    Registry->>Plugin: 转发请求

    Note over Plugin,Registry: 3. 反馈阶段
    Plugin-->>Registry: 返回执行结果
    Registry->>QE: 上报执行指标(延迟/成功/错误)
    QE->>Kernel: 更新评分(持久化到CC/AL)
    Kernel-->>QE: 确认

```

### 三、关键协作流程详解

### 📝 阶段一：注册与准入

**核心逻辑：不仅是“上线”，更是“体检”。**

1. **插件注册**：插件启动时，向 `Registry` 汇报自己的能力（我是谁、我能做什么、我的地址在哪）。
2. **资源预检**：`Registry` 并不是直接记录，而是先找 `Kernel` 的 `ResourceManager` 确认是否有资源（内存/显存）接纳这个新插件。这防止了系统过载。
3. **准入评估**：
   * `Registry` 通知 `QE`。
   * `QE` 查阅 `Kernel` 中的历史数据（`ConfigCenter` 或 `AuditLog`）。如果是老插件重启，它会读取之前的表现；如果是新插件，可能进行快速冒烟测试。
   * **结果**：插件获得一个“初始评分”，只有评分合格的插件才会被标记为“可用”。

### 🚦 阶段二：路由与决策

**核心逻辑：不是“随机轮询”，而是“择优录取”。**

1. **请求发起**：客户端发起调用（例如 `tools/call` 搜索工具）。
2. **智能查询**：`Registry` 不直接返回第一个找到的实例，而是询问 `QE`：“现在谁的状态最好？”
3. **加权决策**：
   * `QE` 根据实时指标（如：当前延迟低、错误率低、最近无异常），计算出一组**权重**。
   * `QE` 返回给 `Registry` 一个排序后的实例列表（例如：实例A权重0.9，实例B权重0.5）。
4. **资源锁定与转发**：
   * `Registry` 选择最优实例（实例A）。
   * 再次确认 `Kernel` 资源状态（防止瞬间并发打满），然后才将请求转发给插件。

### 🔄 阶段三：反馈与进化

**核心逻辑：每一次调用，都是在“训练”路由策略。**

1. **执行与返回**：插件处理完业务，返回结果。
2. **指标上报**：`Registry` 作为代理，截获这次调用的元数据（耗时多少？成功了还是报错了？）。
3. **评分更新**：
   * `Registry` 将这些“实战数据”上报给 `QE`。
   * `QE` 更新算法模型，重新计算该插件的评分。
   * **持久化**：将新评分写入 `Kernel` 的 `ConfigCenter`。
4. **闭环生效**：下一次请求到来时，`QE` 就会基于这个最新的评分来做路由决策。如果插件变慢了，它的权重就会降低，流量就会自动切走。

* * *

### 四、与 Kernel Core 其他模块的交互

| 交互对象                 | 触发时机             | 目的                                    |
| -------------------- | ---------------- | ------------------------------------- |
| **Resource Manager** | 插件注册、路由前资源检查     | 确保插件实例有足够资源运行                         |
| **Inference Engine** | 当插件本身需要调用推理时（间接） | 插件通过 ACI L2/L3 调用 IE，而非 Registry 直接调用 |
| **Config Center**    | 评分更新、策略变更        | 存储/读取评分、路由权重配置                        |
| **Event Bus**        | 插件状态变更、评分更新      | 发布事件供审计、监控消费                          |
| **Audit Log**        | 评分变更、路由决策关键操作    | 记录不可变审计日志                             |

* * *

### 五、设计要点

* **无状态注册表**：`Registry` 本身不持久化评分，只缓存端点；评分由 `Quality Engine` 统一管理，避免状态分散。

* **弹性路由**：`Registry` 定期从 `Quality Engine` 拉取评分快照（缓存），减少实时调用开销；同时支持 `Quality Engine` 主动推送评分变更。

* **故障隔离**：若 `Quality Engine` 不可用，`Registry` 降级为静态权重（基于插件声明的质量等级），保证核心路由不中断。

* **可观测性**：每次路由决策附带 `trace_id`，`Quality Engine` 的评分计算过程也可被追踪，便于审计和调试。

通过这种协作，`ACI Server Registry` 成为**请求入口**，`Quality Engine` 成为**智能决策大脑**，`Kernel Core` 提供**底层资源与安全底座**，三者共同支撑起 AgentOS 的“质量驱动路由”核心能力。
