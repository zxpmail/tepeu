用户空间（User Space）设计
==================

| 项目  | 内容                               |
| --- | -------------------------------- |
| 版本  | v0.1                             |
| 范围  | AgentOS 用户空间组件（ACI Host + 客户端工具） |
| 定位  | 协议网关、能力路由、请求编排、与内核/插件交互的中枢       |

1. 模块概览

-------

用户空间是 AgentOS 中运行在 Kernel 之外的**无状态服务层**，负责接收客户端请求，通过 ACI 协议与插件层交互，并调用 Kernel 能力进行资源检查、质量评分查询、审计等。用户空间的核心组件是 **ACI Host**（包含 ACI Server Registry），以及可选的**客户端 SDK**、**CLI 工具**、**Web 控制台**等。

2. 职责边界

-------

| 负责                                 | 不负责                           |
| ---------------------------------- | ----------------------------- |
| 接收客户端 gRPC/HTTP 请求，路由到目标插件         | 插件业务逻辑执行                      |
| 维护插件注册表（端点、能力、元数据）                 | 插件生命周期管理（由 Plugin Manager 负责） |
| 缓存质量评分和路由权重（定期从 Quality Engine 同步） | 评分计算（由 Quality Engine 负责）     |
| 请求转发、负载均衡、超时控制、重试                  | 底层资源分配（由 Resource Manager 负责） |
| 执行跨层编排（如 L3 会话调用 L1 工具）            | 持久化存储（审计日志、配置由 Kernel 负责）     |
| 上报执行指标到 Event Bus                  | 安全策略执行（由 Security Base 负责）    |

3. 核心组件

-------

| 组件                      | 说明                             |
| ----------------------- | ------------------------------ |
| **ACI Host**            | 主入口，处理所有 ACI 协议请求（L1-L4）       |
| **ACI Server Registry** | 插件注册表，维护可用插件实例列表（内存缓存 + 持久化监听） |
| **Router**              | 根据能力类型和质量评分选择最优插件实例            |
| **Orchestrator**        | 执行跨层编排模板（如客服场景的多步调用）           |
| **Cache Manager**       | 缓存插件端点、质量评分、路由策略               |
| **Metrics Reporter**    | 异步上报请求指标到 Event Bus            |

4. 关键流程

-------

### 4.1 插件注册与发现

1. 插件启动后，通过 gRPC 向 ACI Host 发送 `Register` 请求（携带能力元数据、端点地址、租户 ID）。

2. ACI Host 验证请求（由 Security Base 辅助），将插件信息存入 Registry 缓存。

3. ACI Host 向 Quality Engine 请求初始评分，并订阅该插件的评分变更事件。

4. 插件定期发送心跳（如 10s），超时未收到则从 Registry 中移除。

### 4.2 客户端请求路由

1. 客户端调用 `ACI Host` 的 ACI 接口（如 `tools/call`）。

2. ACI Host 根据请求中的能力名称，从 Registry 查找提供该能力的插件实例列表。

3. 从 Cache Manager 获取这些实例的实时评分和路由权重。

4. Router 根据权重（如评分高权重高）选择一个实例。

5. ACI Host 转发请求到该实例的 gRPC 端点，同时可选调用 Resource Manager 预留资源。

6. 收到响应后返回客户端，并异步上报指标（延迟、成功/失败）到 Event Bus。

### 4.3 跨层编排

* 编排模板（YAML）定义了多步调用顺序（如 L3 会话 → L2 资源 → L1 工具）。

* ACI Host 的 Orchestrator 组件解析模板，按依赖顺序执行调用，聚合结果返回。

* 支持条件分支、并行、超时、重试、补偿。

### 4.4 质量评分同步

* ACI Host 启动时从 Quality Engine 拉取全量评分快照，并开启 Watch 通道。

* Quality Engine 评分变更时推送增量更新，ACI Host 更新本地缓存。

* 若 Quality Engine 不可用，ACI Host 使用最后一次缓存评分，并降级到静态权重（基于插件声明的质量等级）。
5. 数据模型（逻辑）

-----------

| 实体                      | 字段                                                                                | 说明         |
| ----------------------- | --------------------------------------------------------------------------------- | ---------- |
| `RegisteredPlugin`      | plugin_id, tenant_id, capabilities, endpoint, lease_expire, quality_score, weight | 注册的插件实例    |
| `RoutingTable`          | capability_key → list of (plugin_id, weight)                                      | 能力到插件实例的映射 |
| `OrchestrationTemplate` | template_id, steps, dependencies, timeout, compensation                           | 编排模板定义     |

6. 配置模型

-------

yaml

aci_host:
  listen_address: "0.0.0.0:8080"
  grpc_max_recv_size: 4MB
  http_max_body_size: 10MB
  registry:
    heartbeat_interval_sec: 10
    lease_duration_sec: 30
  router:
    default_routing_strategy: "quality_weighted"   # 可选: round_robin, least_load
    fallback_strategy: "static_quality"
  cache:
    quality_ttl_sec: 60
    registry_ttl_sec: 30
  orchestration:
    max_steps: 20
    default_timeout_sec: 60
  metrics:
    export_interval_sec: 5
    backend: "event_bus"   # 或 prometheus

7. 可观测性

-------

* **Metrics**：请求总数、成功率、P99 延迟、路由耗时、缓存命中率、注册插件数。

* **Traces**：每个请求生成 trace，跨 ACI Host、插件、Kernel 调用传递 trace_id。

* **Audit**：关键操作（插件注册、路由决策、编排执行）由 ACI Host 写入审计日志（通过 Event Bus）。
8. 高可用与扩展

---------

* **无状态设计**：ACI Host 可水平扩展（多副本），通过 K8s Service 或 Nacos 做负载均衡。

* **缓存一致性**：使用 Config Center 的 Watch 机制或 Redis Pub/Sub 同步评分变更。

* **降级**：Quality Engine 不可用时，路由降级为静态权重；Registry 依赖持久化存储（Config Center）恢复注册信息。
9. 安全

-----

* **mTLS**：ACI Host 与插件、内核之间强制 mTLS 认证。

* **租户隔离**：每个租户的插件注册表逻辑隔离，请求携带 tenant_id，只路由到该租户的插件实例。

* **限流**：支持按租户、按能力的 QPS 限流（由 Spring Cloud Gateway 或自研组件实现）。
10. 与内核及插件的接口摘要

---------------

| 调用方向                        | 接口                                   | 协议         | 用途   |
| --------------------------- | ------------------------------------ | ---------- | ---- |
| 客户端 → ACI Host              | ACI L1-L4                            | gRPC/HTTP  | 业务请求 |
| ACI Host → 插件               | 插件实现的 ACI 接口                         | gRPC       | 转发请求 |
| ACI Host → Quality Engine   | `GetRoutingCandidates`, `WatchScore` | gRPC       | 查询评分 |
| ACI Host → Resource Manager | `CheckResource`                      | gRPC       | 资源预检 |
| ACI Host → Event Bus        | `PublishMetrics`                     | Kafka/gRPC | 上报指标 |
| ACI Host → Audit Log        | `WriteAudit`                         | gRPC       | 审计日志 |

11. 测试要点

--------

* 单元测试：路由算法、缓存刷新、编排解析。

* 集成测试：注册、心跳、路由、降级、编排执行。

* 混沌测试：ACI Host 副本宕机、Quality Engine 不可用、网络分区。
