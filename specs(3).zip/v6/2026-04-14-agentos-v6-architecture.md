# 智能中枢（AgentOS）系统架构设计文档

## v6.0 微内核版（开放协议 + 质量驱动 + 生态自治）

| 项        | 内容                                      |
| -------- | --------------------------------------- |
| **版本**   | 6.0                                     |
| **日期**   | 2026-04-14                              |
| **作者**   | AgentOS 架构组                             |
| **核心范式** | 微内核 + 标准协议 + 评估驱动 + 生态自治                |
| **发布策略** | v6.0 GA（稳定基线）→ v6.1（多智能体协调）→ v6.2（联邦调度） |

### 修订历史

| 版本    | 日期         | 修改内容                                                            |
| ----- | ---------- | --------------------------------------------------------------- |
| 6.0.1 | 2026-04-14 | 增补 §18–§20：GA 工程化行动项（归因/依赖/激励/基准/模板/混沌/沙箱/CI）、里程碑表与投产总结         |
| 6.0   | 2026-04-14 | 微内核 + ACI 四层 + Quality Engine + 生态分级；补齐协议对齐、跨层编排、治理覆盖、威胁模型与测量口径 |
| 3.0   | 2026-04-09 | 融合版（资源管理 + 业务功能），见历史规格 `2026-04-09-agentos-design.md`           |

### 与历史规格（v3.0）关系

- **保留思想**：“Kubernetes for AI Agents” 隐喻、供给/调度/计量/隔离/编排。
- **v6.0 变化**：业务功能从“内核内服务”外迁为 **官方插件**；资源与推理进入 **Kernel Core**；能力边界以 **ACI** 规范化；新增 **质量驱动路由** 与 **三级生态准入**。
- **映射提示**：WorkFlow / AgentFlow / Multi-Agent 等能力在 v6.0 中主要对应 `workflow-engine`、`agent-orchestrator`、`multi-agent-coord` 等插件，通过 ACI 与内核交互。

---

## 目录

1. [架构愿景与核心范式](#1-架构愿景与核心范式)
2. [微内核架构全景](#2-微内核架构全景)
3. [AgentOS Kernel 核心设计](#3-agentos-kernel-核心设计)
4. [标准能力接口（ACI）规范](#4-标准能力接口aci规范)
5. [质量评估与驱动体系](#5-质量评估与驱动体系)
6. [官方插件体系](#6-官方插件体系)
7. [第三方插件开发指南](#7-第三方插件开发指南)
8. [部署模式与版本矩阵](#8-部署模式与版本矩阵)
9. [v5.0 至 v6.0 迁移指南](#9-v50-至-v60-迁移指南)
10. [安全与隔离机制](#10-安全与隔离机制)
11. [威胁模型（摘要）](#11-威胁模型摘要)
12. [可观测性与治理](#12-可观测性与治理)
13. [生态治理与认证体系](#13-生态治理与认证体系)
14. [性能基准与优化](#14-性能基准与优化)
15. [故障治理与韧性](#15-故障治理与韧性)
16. [安全加固与可信](#16-安全加固与可信)
17. [风险缓解与实施路径](#17-风险缓解与实施路径)
18. [工程化与 GA 投产：关键行动项](#18-工程化与-ga-投产关键行动项)
19. [从当前到 GA 的里程碑路线图](#19-从当前到-ga-的里程碑路线图)
20. [从蓝图到可投产的关键跨越](#20-从蓝图到可投产的关键跨越)
21. [附录](#21-附录)

---

## 1. 架构愿景与核心范式

### 1.1 架构演进

| 阶段       | 架构特征         | 核心问题               | 解决方式                   |
| -------- | ------------ | ------------------ | ---------------------- |
| v3.4     | 单体 Java      | JNI 风险、虚假参数        | 物理隔离                   |
| v4.0     | 双栈分离         | 治理规则缺失             | 诚实参数、API 契约            |
| v5.0     | 工程护栏         | 实施鸿沟、组织协同          | 风险缓解附录                 |
| **v6.0** | **微内核 + 生态** | **功能耦合、质量参差、定制困难** | **标准协议 + 评估驱动 + 开放生态** |

### 1.2 核心范式：四大支柱

| 支柱              | 说明                                         | 关键承诺                                                  |
| --------------- | ------------------------------------------ | ----------------------------------------------------- |
| **微内核**         | 最小功能集（资源管理、推理托管、安全基座、插件生命周期）；目标：内核相关代码占比可控 | 内核对外 **Kernel API v1** 向后兼容至后续三个大版本（规划至 v9.0），以发布说明为准 |
| **标准能力接口（ACI）** | 四层协议（基础工具、语义资源、会话上下文、质量评估），强制向后兼容          | 层内独立版本；废弃提前12 个月公告                                    |
| **质量评估驱动**      | 全生命周期评估（认证 + 运行时 + 客户自定义），评分参与路由           | 质量系统资源开销与延迟预算见 [§14.3](#143-质量系统开销与测量口径)              |
| **生态自治**        | 三级准入（官方 / 认证 / 社区），能力发现，激励相容               | 劣币驱逐防护；升级路径明确                                         |

### 1.3 设计原则

| 原则     | 说明                              | 反模式                 |
| ------ | ------------------------------- | ------------------- |
| 内核最小化  | 功能经 ACI 扩展，避免“顺手改内核”            | 为短期需求堆叠内核分支         |
| 协议分层演进 | ACI 各层独立版本；**禁止插件绕过宿主**直连内核私有实现 | 插件直接读内核内部状态或未公开 RPC |
| 评估即治理  | 插件具备可观测评分；**自动路由以机器评分为默认**      | 无评估灰度生产；无审计的“口头优先”  |
| 能力自治   | 插件自描述能力，由宿主匹配与编排                | 硬编码插件类型与静态绑定        |
| 安全默认   | 沙箱、交互式授权、最小权限                   | 默认全开、隐式信任           |
| 性能可验证  | 优化与 SLO 以基准与压测支撑                | 仅定性描述无量化与复现路径       |

### 1.4 跨层协作规则（澄清“禁止跨层调用”）

- **禁止**：插件 **绕过** `ACI Host` / `Kernel` 公开 API，直接访问其他插件进程、内核私有存储或未文档化接口。
- **允许**：由 **`ACI Host` 编排** 形成的跨层工作流（例如 L3 会话触发 L1 工具、L4 提交评估结果反馈给路由）。
- **规范**：允许的层间依赖以 **有向无环图（DAG）** 表达，默认路径为  
  `Client → ACI Host → (L1|L2|L3|L4 组合) → Plugin(s) → Kernel Core`  
  具体组合由产品附录中的 **编排模板** 固化（模板版本与 ACI 层版本绑定）。

---

## 2. 微内核架构全景

### 2.1 运行时架构

```
+-----------------------------------------------------------------------------+
|                         用户空间 (User Space)                                |
|  +-------------+  +-------------+  +-------------+  +---------------------+ |
|  | IDE 集成    |  | 对话界面    |  | 自动助手    |  | Eval Studio         | |
|  | 客户端      |  | 客户端      |  | 客户端      |  | (评估工作室)        | |
|  +------+------+  +------+------+  +------+------+  +----------+----------+ |
|         |                |                |                   |            |
|         +----------------+----------------+-------------------+            |
|                                    |                                        |
|                            +-------v--------+                               |
|                            |  ACI Host      |  标准能力接口宿主              |
|                            |  (协议路由)    |  发现/调用/上下文/策略点       |
|                            +-------+--------+                               |
+------------------------------------|----------------------------------------+
                                     |
+------------------------------------v----------------------------------------+
|                        AgentOS Kernel 6.0                                   |
|  +-----------------------------------------------------------------------+  |
|  |                    ACI Server Registry                                |  |
|  |  +--------+ +--------+ +--------+ +--------+ +----------------------+   |  |
|  |  | Tool   | |Resource| | Prompt | |Sampling| | Admin/Bootstrap Svc  |   |  |
|  |  | Server | | Server | | Server | | Server | | (原 Root Server 职责) |   |  |
|  |  +--------+ +--------+ +--------+ +--------+ +----------------------+   |  |
|  |  L1 tools/list, tools/call                                              |  |
|  |  L2 resources/read, prompts/get, sampling/create                        |  |
|  |  L3 session/create, session/append, checkpoint/save                     |  |
|  |  L4 eval/submit, quality/adjust, report/generate                        |  |
|  +-----------------------------------------------------------------------+  |
|                                     |                                       |
|  +-----------------------------------------------------------------------+  |
|  | Quality Engine                                                          |  |
|  |  SuiteRegistry / BenchMark / TaskExecutor / MetricStore / ReportEngine |  |
|  +-----------------------------------------------------------------------+  |
|                                     |                                       |
|  +-----------------------------------------------------------------------+  |
|  |                    Kernel Core                                        |  |
|  |  ResourceManager | InferenceEngine | ServiceMesh | SecurityBase        |  |
|  |  PluginManager   | EventBus        | AuditLog    | ConfigCenter       |  |
|  +-----------------------------------------------------------------------+  |
+-----------------------------------------------------------------------------+
                                     |
+------------------------------------v----------------------------------------+
|                         插件层 (Plugins)                                    |
|  ACI Tool / ACI Resource / Workflow / Agent Orchestrator / ...              |
|  每个插件暴露 ACI；可选原生 SPI（遗留，逐步淘汰）                              |
+-----------------------------------------------------------------------------+
```

**命名说明**：原“Root Server”更名为 **Admin/Bootstrap Service**（或 **Control Plane Bootstrap**），仅承担注册、引导、紧急策略下发等控制面职责，避免与 PKI“信任根”混淆。

### 2.2 控制流与数据流

**控制流（Quality-Driven）**  
请求 → ACI Host → 能力匹配 → Quality Engine 评分筛选与路由策略 → 插件执行 → 质量反馈闭环。

**数据流（Secure Isolation）**

| 数据类型     | 托管方              | 访问方式       | 隔离级别 |
| -------- | ---------------- | ---------- | ---- |
| 模型权重     | Inference Engine | 只读句柄       | 内核级  |
| KV Cache | 推理实例             | 无跨租户暴露     | 进程级  |
| 会话状态     | Session（L3）      | ACI L3 API | 租户级  |
| 向量数据     | Resource Manager | ACI L2 API | 权限级  |
| 评估指标     | Quality Engine   | 只读/授权      | 系统级  |
| 审计日志     | Audit Log        | 查询接口       | 合规级  |

---

## 3. AgentOS Kernel 核心设计

### 3.1 Resource Manager（资源管理器）

**能力（概念 YAML）**

```yaml
capabilities:
  compute:
    gpu: { vendors: [NVIDIA, Ascend, DCU, MLU], features: [MIG, vGPU, time-slicing] }
    cpu: { features: [cgroup, numa-binding] }
    memory: { features: [hugepage, EMS-offload] }
  scheduling:
    policies:
      - name: quality-priority
        weights: { quality_score: 0.4, latency_requirement: 0.3, fairness: 0.3 }
      - name: cost-optimized
        features: [spot-instance, checkpoint-resume]
      - name: realtime-guarantee
        features: [resource-reservation, preemption-disable]
    quality_aware:
      a_grade_boost: 1.5
      c_grade_penalty: 0.5
      preemption_threshold: 60
  isolation:
    tenant: [namespace, quota, limit, network-policy]
    sandbox: [container, gvisor, firecracker, wasm]
```

**关键 gRPC（节选）**

```protobuf
service ResourceManager {
  rpc Allocate(AllocateRequest) returns (AllocateResponse);
  rpc Release(ReleaseRequest) returns (Empty);
  rpc WatchMetrics(StreamMetricsRequest) returns (stream MetricsEvent);
  rpc ReportQuality(QualityReport) returns (Empty);
}

message QualityRequirement {
  int32 min_score = 1;
  string preferred_tier = 2;
  bool require_a_grade = 3;
}
```

### 3.2 Inference Engine（推理引擎）

```yaml
capabilities:
  model_lifecycle: [download, verify, load, warmup, serve, unload, archive, evaluate]
  session_management:
    abstraction: "ACI L3 Session"
    features: [multi-turn-context, tool-binding, checkpoint-resume, cross-model-transfer]
  quality_integration:
    runtime_profiling: true
    auto_tuning: true
    degradation_alert: true
```

### 3.3 Quality Engine（质量引擎）

**三层评估**

| 层级    | 触发  | 内容                 | 输出         |
| ----- | --- | ------------------ | ---------- |
| 认证评估  | 上架前 | 功能、性能、可靠性、安全、文档    | 等级 A/B/C/D |
| 运行时评估 | 持续  | 成功率、延迟、资源效率、用户反馈聚合 | 实时分、趋势     |
| 客户自定义 | 按需  | 私有套件、合规            | 合规报告       |

**高可用与降级**

```yaml
deployment: "3 节点 Raft 集群"
data_replication: "同步复制，目标 RPO=0"
failover: "自动切换，目标 RTO < 5s（见 §14.3 测量口径）"
degradation_levels:
  - level: 0
    behavior: "实时评分，动态路由"
  - level: 1
    behavior: "只读缓存模式，评分不更新"
  - level: 2
    behavior: "静态降级，预配置默认权重"
  - level: 3
    behavior: "紧急模式，轮询路由，全量审计"
```

**防操纵（多源验证）**

```yaml
validation_layers:
  - layer: self_reported
    weight: 0.2
    verification: "必须附带原始日志哈希"
  - layer: kernel_observed
    weight: 0.4
    source: "Service Mesh 指标"
  - layer: client_feedback
    weight: 0.2
    verification: "签名与防重放；PII 最小化"
  - layer: third_party_audit
    weight: 0.2
    mechanism: "随机抽样，独立评分"
tamper_proof:
  technology: "Merkle Tree + 周期性锚定（可验证历史完整性）"
```

---

## 4. 标准能力接口（ACI）规范

### 4.1 与 MCP 的协议对齐（规范性说明）

- **定位**：ACI **对齐** [Model Context Protocol (MCP)](https://modelcontextprotocol.io) 的 **Tools / Resources / Prompts / Sampling** 语义；在 MCP 之上扩展 **L3 会话组合** 与 **L4 质量层**。
- **兼容策略**：
  - **桥接模式**：外部 MCP Server 经 `ACI Host` 适配注册，映射到 L1/L2；会话与评估仍由内核托管。
  - **认证映射**：MCP `meta` / ACI `annotations` 互转；错误码经统一表（见附录）映射。
- **非目标**：不要求 MCP 客户端直接理解 L4；L4 仅对宿主与受信控制面组件暴露。

### 4.2 四层架构

| 层级  | 核心能力                                         | 典型延迟（目标，非保证） | 场景        |
| --- | -------------------------------------------- | ------------ | --------- |
| L1  | tools/list, tools/call                       | 5–10 ms量级    | 工具、转换     |
| L2  | resources/read, prompts/get, sampling/create | 10–50 ms 量级  | RAG、模板、采样 |
| L3  | session/create, append, checkpoint           | 50–100 ms 量级 | 多轮、恢复     |
| L4  | eval/submit, quality/adjust, report/generate | 10–50 ms 量级  | 反馈、路由、合规  |

### 4.3 核心接口（节选）

**L1 Tool Server**

```protobuf
service ToolServer {
  rpc ListTools(ListToolsRequest) returns (ListToolsResponse);
  rpc CallTool(CallToolRequest) returns (CallToolResponse);
}
message CallToolRequest {
  string name = 1;
  google.protobuf.Struct arguments = 2;
  string session_id = 3;
  QualityRequirement quality = 4;
}
```

**L3 Session**

```protobuf
service SessionManager {
  rpc CreateSession(CreateSessionRequest) returns (Session);
  rpc AppendMessage(AppendMessageRequest) returns (Session);
  rpc RunToolLoop(RunLoopRequest) returns (stream LoopEvent);
}
```

### 4.4 版本管理

```yaml
aci_versions:
  v1.0:
    status: stable
    released: "2026-04-14"
    support_until: "2029-04-14"
    layers: [L1, L2, L3]
  v1.1:
    status: beta
    target_release: "2026-Q3"
    new_features: ["L4 增强", "cross-model-session-transfer"]
compatibility:
  policy: "向后兼容；层内独立版本"
  deprecation: "提前 12 个月公告"
  migration_tools: "aci-migrate CLI"
```

---

## 5. 质量评估与驱动体系

### 5.1 机器评分与治理覆盖（Governance Override）

| 概念                      | 定义                            | 约束                                     |
| ----------------------- | ----------------------------- | -------------------------------------- |
| **Machine Score**       | 由 Quality Engine 按多源权重计算的自动分数 | 默认用于路由与排序                              |
| **Governance Override** | 合规冻结、事故豁免、法务裁定、客户策略覆盖         | **必须**：双人控制、全链路审计、有效期、自动回滚提醒；禁止无审计静默改分 |

### 5.2 路由滞回与探索流量

- **滞回**：路由权重变更需满足 **最小时间窗口 + 最小幅度**，避免评分噪声导致抖动。
- **探索流量**：小比例流量探测低分插件新版本；与生产流量隔离预算与 SLO。

### 5.3 评分突降处理（示例逻辑）

```python
def on_score_drop(plugin_id, old_score, new_score):
    if new_score < old_score - 20:
        immediate_isolate(plugin_id)
        alert(level="P0")
    elif new_score < old_score - 10:
        gradual_degrade(plugin_id, steps=3, window="5m")
        alert(level="P1")
    elif new_score < 70 and old_score >= 70:
        mark_for_review(plugin_id)
        trigger_root_cause_analysis()
    schedule_recovery_probe(plugin_id, interval="10m")
```

**补充**：执行隔离前应尽量完成 **归因**（依赖插件、下游推理、网络分区），支持 **金丝雀发布与自动回滚**。

### 5.4 质量驱动运行时

```
插件提交 → 认证套件 → 定级 → 上架运行监控 → 指标聚合 → 实时分 → 权重调整
路由决策 → 可解释推荐 → 执行 → 审计记录
```

### 5.5 路由与降级状态机

状态说明（中文 / English）：正常（Normal）、降级缓存（Degraded Cache）、静态权重（Static Weights）、紧急轮询（Emergency Round Robin）、治理冻结（Governance Hold）。

```mermaid
stateDiagram-v2
  [*] --> Normal
  Normal: 正常 / Normal
  DegradedCache: 降级缓存 / Degraded Cache
  StaticWeights: 静态权重 / Static Weights
  EmergencyRoundRobin: 紧急轮询 / Emergency Round Robin
  GovernanceHold: 治理冻结 / Governance Hold
  Normal --> DegradedCache: QE_level1 / 单节点故障
  DegradedCache --> StaticWeights: QE_level2 / 多数故障
  StaticWeights --> EmergencyRoundRobin: QE_level3 / 完全不可用
  EmergencyRoundRobin --> Normal: QE_recovered / 恢复
  Normal --> GovernanceHold: override_active / 启用治理覆盖
  GovernanceHold --> Normal: override_expired / 覆盖过期
```

---

## 6. 官方插件体系

### 6.1 清单（示例）

| 插件                 | 职责   | ACI 层级      | 质量等级（目标） | 资源（参考）   |
| ------------------ | ---- | ----------- | -------- | -------- |
| workflow-engine    | 流程编排 | L1–L3       | A        | 2C4G     |
| agent-orchestrator | 智能编排 | L1–L4       | A        | 2C4G     |
| service-registry   | 服务发现 | L1          | B        | 2C4G     |
| task-executor      | 任务执行 | L1          | B        | 按需       |
| metering-collector | 计量   | L1          | A        | 1C2G     |
| billing-engine     | 计费   | L1          | B        | 1C2G     |
| security-enhanced  | 安全增强 | L1–L2       | A        | 1C2G     |
| model-market       | 模型市场 | L1–L2       | B        | 2C4G     |
| knowledge-base     | 知识库  | L2–L3       | B        | 4C8G+GPU |
| multi-agent-coord  | 多智能体 | L3–L4（v6.1） | B        | 4C8G     |

### 6.2 组合模式

| 模式         | 组件                                                       | 场景   |
| ---------- | -------------------------------------------------------- | ---- |
| Edge       | Kernel + task-executor                                   | 边缘   |
| Standard   | Kernel + workflow-engine + agent-orchestrator + metering | 中小企业 |
| Enterprise | 全官方插件                                                    | 大型集团 |
| Custom     | 自选 + 第三方                                                 | 定制   |

---

## 7. 第三方插件开发指南

### 7.1 快速开始

```bash
pip install agentos-sdk
agentos-cli plugin create --name my-plugin --language python --aci-layers L1,L2 --output ./my-plugin/
cd my-plugin/
agentos-cli plugin test
agentos-cli plugin submit
```

### 7.2 最小示例（概念）

```python
from agentos_sdk import Plugin, Tool, ACIServer, QualityReporter

@ACIServer(layers=["L1", "L2"])
class DataAnalyzerPlugin(Plugin):
    @Tool(name="analyze_csv", description="...", input_schema={...})
    def analyze_csv(self, file_path: str, columns: list, metrics: list):
        result = self.do_analysis(file_path, columns, metrics)
        return {"report": result, "_quality": {"confidence": 0.95, "execution_time_ms": 120}}

    @QualityReporter
    def estimate_quality(self):
        return {"functional_score": 0.90, "performance_score": 0.85, "reliability_score": 0.92}
```

---

## 8. 部署模式与版本矩阵

### 8.1 硬件（参考）

| 版本         | CPU  | 内存    | GPU           | 场景     |
| ---------- | ---- | ----- | ------------- | ------ |
| Edge       | 4核   | 16GB  | 可选            | 边缘     |
| Standard   | 8 核  | 32GB  | RTX 4090 24GB | 7B–13B |
| Enterprise | 64 核 | 256GB | 8×A100 40GB   | 70B+   |

### 8.2 兼容性矩阵（示例）

```
              Kernel 6.0  6.1    6.2    7.0
Plugin A      1.0 兼容   1.0    1.1    2.0 需升级
Plugin B      2.0 兼容   2.0    2.0    2.0 兼容
Plugin C      1.0 兼容   1.0    1.0 弃警告  不再支持
（图例：兼容 / 弃警告 / 需升级 / 不再支持 —以发布说明为准）
```

---

## 9. v5.0 至 v6.0 迁移指南

| v5.0 组件            | v6.0 映射                        |
| ------------------ | ------------------------------ |
| WorkFlow Service   | workflow-engine插件              |
| AgentFlow Service  | agent-orchestrator 插件          |
| Resource Registry  | Resource Manager + registry 插件 |
| Compute Scheduler  | Resource Manager               |
| Metering & Billing | metering + billing 插件          |
| 推理面 (Python)       | Inference Engine               |

```bash
agentos-migrate analyze --from 5.0 --to 6.0 --config /v5.0/config/
agentos-migrate generate --output ./migration-plan/
agentos-migrate validate --target 6.0
```

---

## 10. 安全与隔离机制

### 10.1 四层隔离

| 层级  | 机制     | 实现                   |
| --- | ------ | -------------------- |
| 应用  | 进程隔离   | 容器 / WASM / MicroVM  |
| 服务  | API 边界 | gRPC + mTLS          |
| 资源  | 配额     | MIG / cgroup / NUMA  |
| 租户  | 逻辑隔离   | 命名空间 / NetworkPolicy |

### 10.2 插件安全模型（示例）

```yaml
security_policy:
  default: deny
  plugin_permissions:
    - name: workflow-engine
      permissions: ["kernel.inference:read", "kernel.audit:write"]
      denied: ["kernel.resource:allocate", "kernel.plugin:lifecycle"]
    - name: untrusted-third-party
      sandbox: firecracker-microvm
      network: egress-deny
      permissions: []
```

---

## 11. 威胁模型（摘要）

| 资产      | STRIDE 关注点 | 缓解要点                                |
| ------- | ---------- | ----------------------------------- |
| 插件代码与配置 | T, E       | 沙箱、签名校验、供应链扫描                       |
| 会话与租户数据 | S, I       | mTLS、租户级加密、最小暴露 L3 API              |
| 质量评分与路由 | T, E, R    | 多源验证、Merkle 锚定、治理覆盖审计               |
| 市场与计量   | T, R       | 防刷、限流、对账与第三方审计                      |
| 控制面引导   | S, E       | Admin/Bootstrap 强认证、 break-glass 流程 |

**隐私**：`client_feedback` 默认脱敏与聚合；租户间评分详情默认不可见；合规导出需授权。

---

## 12. 可观测性与治理

### 12.1 SLO（目标）

| 指标       | 目标     | 告警阈值（示例）      |
| -------- | ------ | ------------- |
| 控制面可用性   | 99.99% | 连续 1 min 不可用  |
| 推理面可用性   | 99.9%  | 连续 5 min      |
| P99 单次推理 | < 2s   | > 3s 持续 5 min |
| 质量系统可用性  | 99.95% | 降级缓存模式        |

### 12.2 发布门禁

- 性能回归：P99 ≤ 基线 110%
- 错误率：灰度 > 0.1% 自动回滚
- 资源水位：GPU 峰值 ≤ 历史 115%

---

## 13. 生态治理与认证体系

### 13.1 三级准入

| 等级  | 费用   | 周期   | 失败策略      | 升级路径       |
| --- | ---- | ---- | --------- | ---------- |
| 官方  | 免费   | ~2 周 | N/A       | 随内核        |
| 认证  | 按次计费 | ~4 周 | 重试策略由运营公布 | C→B 需稳定表现期 |
| 社区  | 免费   | 自动扫描 | 长期 C 或下架  | B→A 需认证    |

### 13.2 跨插件依赖与 Bundle 质量

```yaml
dependency_management:
  declaration:
    format: plugin.yaml
    constraints: [version_range, quality_level, compatibility_matrix]
  resolution:
    strategy: "SAT + 用户 pin 优先；冲突时失败并输出可解释原因"
  bundle_quality:
    formula: "weighted_average(dependents) * compatibility_factor"
    threshold: ">= 70 才允许部署（可配置）"
```

### 13.3 防劣币（经济 + 排序）

- 搜索排序向高等级倾斜；默认市场过滤器可设最低质量 **B**。
- 激励与处罚需 **激励相容**：与经济惩罚联动审计，防止刷分刷评。

---

## 14. 性能基准与优化

### 14.1 端到端延迟分解（目标区间）

| 路径                        | 延迟（量级）    | 手段       |
| ------------------------- | --------- | -------- |
| Client → ACI Host         | ~0.5 ms   | 连接池、会话复用 |
| ACI Host → Registry       | ~0.3 ms   | 本地缓存、订阅  |
| Registry → Quality Engine | ~1 ms     | 多级缓存     |
| QE → Plugin               | ~0.5 ms   | 预计算权重    |
| Plugin → Kernel           | ~2 ms     | 资源预留     |
| Kernel → Inference        | 50–200 ms | 批处理、前缀缓存 |

### 14.2 高并发

| 场景      | QPS | P99    | P999   |
| ------- | --- | ------ | ------ |
| L1 工具   | 10k | 15 ms  | 50 ms  |
| L2 资源   | 5k  | 100 ms | 300 ms |
| L3 会话推理 | 500 | 2 s    | 5 s    |

### 14.3 质量系统开销与测量口径

**承诺（需在 CI 以固定场景复现）**：

- 质量系统合计 CPU **< 10%**、延迟增加 **< 5 ms**（在 **缓存命中**、**不含冷启动**、**含 mTLS** 的基准环境下）。
- **RTO < 5 s**：指 Quality Engine Raft 组 **主切换** 在标准三节点、同可用区网络下的 **P95** 目标。

**每次发布**：附 `bench-report` 工件名、配置快照、Git 提交 SHA。

---

## 15. 故障治理与韧性

- Quality Engine：Raft、四级降级（见 §3.3）。
- Plugin Manager崩溃：存活探针、注册表恢复。
- Session 中断：checkpoint + 心跳超时恢复。
- 推理 OOM：cgroup 监控、重启与流量切换、幂等重试。

---

## 16. 安全加固与可信

- 评分多源验证 + Merkle 锚定（§3.3）。
- **行为监控规则示例**：异常外联、越权访问租户数据、资源飙升、内核 API 异常频度 → 限流、熔断、终止。

---

## 17. 风险缓解与实施路径

| 风险    | 缓解                    | 责任   |
| ----- | --------------------- | ---- |
| 协议栈开销 | 缓存、预计算、快速路径           | 平台   |
| QE 单点 | Raft、降级               | 平台   |
| 评分操纵  | 多源验证、审计               | 安全   |
| 生态劣币  | 排序、激励、清退              | 生态运营 |
| 依赖地狱  | SAT + bundle 阈值 + pin | 平台   |

**路线图（规划）**

- 2026-Q2：v6.0-alpha（内核、workflow、orchestrator、SDK）
- 2026-Q3：v6.0-beta（内测、种子客户、市场 MVP）
- 2026-Q4：v6.0-GA
- 2027-Q1：v6.1（multi-agent、ACI v1.1、联邦预览）

季度级方向如上；**按月交付物划分的 GA 工程化里程碑**见 [§19](#19-从当前到-ga-的里程碑路线图)。

---

## 18. 工程化与 GA 投产：关键行动项

本节将 v6.0 从「优秀架构蓝图」推进到可投产 GA 所需的工程化闭环：每项包含**产出**、**验收标准**、**责任角色**（R：牵头 / C：协作）。

### 18.1 质量引擎：从输出格式到自动归因与异常检测

**现状**：文档已定义评分突降处理与多源验证，但未规定运行时自动归因与异常检测的训练、部署方式。

**投产要求**：

- 归因分析能在运行时自动识别导致评分下降的主要维度（延迟、错误率、资源效率）及根因类型（依赖插件故障、输入分布漂移、内核资源争抢等）。
- 异常检测能区分评分操纵（刷分）与真实质量退化：**误报率 &lt; 5%**，**漏报率 &lt; 1%**（在约定测试集与标注协议下）。

**实施步骤**：

| 步骤   | 内容                                                                                 |
| ---- | ---------------------------------------------------------------------------------- |
| 数据采集 | 在 ACI Host 与 Kernel 埋点：插件 ID、响应时间、错误码、输入规模、依赖调用链、GPU 显存/CPU 等；写入时序库（如 ClickHouse）。 |
| 特征工程 | 根因特征向量：延迟/错误率/资源效率变化率、依赖健康度、输入长度分位数等。                                              |
| 归因模型 | 离线 SHAP / 因果森林等得到特征贡献；规则后处理（如依赖失败率 &gt; 10% → 依赖类根因）。                              |
| 异常检测 | 孤立森林或 LSTM-AE 等离线训练评分序列异常；并行规则库（如短窗口内同源异常剧变）。                                      |
| 集成   | 模型以 Quality Engine 内微服务（如 Python）暴露，**gRPC** 调用；历史数据回放做离线 A/B，对比人工标注。              |
| 人工复核 | 自动归因写入审计表；质量委员会可校正，校正样本回灌训练。                                                       |

**验收标准**：

- 已知故障场景（依赖崩溃、输入峰值等）归因准确率 **≥ 90%**。
- 异常检测在测试集 **AUC ≥ 0.95**。
- 归因计算 **P99 ≤ 50 ms**。

**责任角色**：R质量工程 / C 平台、数据、安全、内核。

---

### 18.2 依赖求解器：从「SAT + pin」到可运行代码

**现状**：文档提出 SAT + 用户 pin，缺少可执行规范与实现。

**投产要求**：

- Plugin Manager 能解析插件依赖图并选出兼容版本集合；**无解**时返回可操作的冲突说明（如「插件 A 需要 tool:foo ≥ 1.2，当前 1.1」）。
- 支持 **semver**（`^` `~` `>=` `&lt;` 等）与**质量等级**约束（如 requires quality ≥ B）。

**实施步骤**：

| 步骤   | 内容                                                                |
| ---- | ----------------------------------------------------------------- |
| 选型   | PubGrub 类算法、Maven 调解策略，或自研回溯求解器（插件规模预期 &lt; 1000 时可接受）。           |
| 实现   | `DependencyResolver`：输入 `plugin.yaml` 的 requires + 已安装集，输出合法版本组合。 |
| 冲突解释 | 无解时生成**解释树/冲突链**（至少一条根因链）。                                        |
| 集成   | `agentos plugin install`、`agentos bundle deploy` 自动调用。            |

**验收标准**：

- 100 个随机**有效**依赖图求解成功率 **100%**，单次求解 **&lt; 100 ms**（约定硬件）。
- 无解图必返回至少一条**根因冲突链**。

**责任角色**：R 插件与工具链 / C 平台、生态。

---

### 18.3 经济激励与审计联动：从概念到流程

**现状**：仅概念性描述「经济惩罚联动审计」。

**投产要求**：

- 保证金或信誉分可执行；恶意刷分、破坏系统可扣减并依规公示。
- **争议仲裁**有明确流程与仲裁委员会。

**实施步骤**：

| 步骤  | 内容                                                                    |
| --- | --------------------------------------------------------------------- |
| 信誉分 | 例如初始 100；上架/好评/差评/违规规则需写死；严重违规清零 + 禁售期（如 6 个月）。                       |
| 保证金 | 认证插件保证金与 **EULA**、赔付条款绑定。                                             |
| 审计  | 评分、路由、插件调用、Governance Override 全进**不可变审计**，关联 `trace_id`、`plugin_id`。 |
| 仲裁  | 委员会 ≥3 人（客户代表、平台、独立专家）；争议单 **5 个工作日内**裁决（SOP）。                        |
| 执行  | 裁决后扣保证金、通报；情节严重者永久封禁。                                                 |

**验收标准**：

- 信誉分与保证金管理**界面或 API**可用。
- 争议仲裁 **SOP** 发布，并在测试环境**跑通一次完整流程**。

**责任角色**：R 生态与法务 / C 平台、安全、财务。

---

### 18.4 基准环境与性能测试：从目标到可复现基线

**现状**：有 SLO 与开销承诺，缺固定环境与自动化脚本。

**投产要求**：

- 每次发布前自动性能回归，**门禁**判定；他人可在标准环境**复现**。

**实施步骤**：

| 步骤   | 内容                                                             |
| ---- | -------------------------------------------------------------- |
| 环境固化 | `bench-env.yaml`：云实例型号或裸金属、CPU/内存/盘/GPU/驱动/内核版本。               |
| 压测   | k6 / ghz 等：L1 10k QPS、L2 5k QPS、L3 推理 500 QPS 等场景，每场景 ≥10 min。 |
| 指标   | Prometheus 拉取，输出 P99/P999、错误率、资源利用率。                           |
| 基线   | 首次结果为基线（S3/制品库 + Git SHA）；后续 MR **P99 恶化 &gt; 10%** 等规则**阻断**。 |
| 质量开销 | 对比「静态权重」与「完整质量引擎」路径，验证开销承诺（见 §14.3）。                           |

**验收标准**：

- `make perf-test`（或等价）**一键**运行，约 **10 min** 内出报告。
- 回归超阈**自动阻断**并通知。

**责任角色**：R 平台 SRE / C 内核、QE。

---

### 18.5 编排模板：从附录缺失到可复制场景

**现状**：文档称模板由产品附录固化，尚无实例。

**投产要求**：至少 **2** 个跨层 DAG 模板，可导入即用。

**实施步骤**：

| 场景     | 路径概要                                                           |
| ------ | -------------------------------------------------------------- |
| 智能客服   | 用户消息 → L3 会话 → Agent Orchestrator → L2 知识检索 → L1 工单工具 → L3 更新。 |
| 批量数据处理 | Workflow 触发 → 并行 L1 清洗/特征 → L2 写入向量库。                          |

模板采用 **ACI Orchestration Template v1**（YAML/DSL）：节点类型、依赖、超时、重试、补偿；可选 BPMN 对照。官方包内置；CLI：`agentos template list` / `apply`。

**验收标准**：干净环境导入后**端到端跑通**，日志与 trace 完整。

**责任角色**：R 产品 + 官方插件 / C 文档、平台。

---

### 18.6 质量引擎高可用与降级：混沌测试验证

**现状**：四级降级状态机未经验证。

**投产要求**：混沌实验证明单节点故障下仍满足承诺，且**核心推理**不明显受损。

**实施步骤**：

| 步骤   | 内容                            |
| ---- | ----------------------------- |
| 环境   | 3 节点 QE Raft + 负载客户端。         |
| 故障注入 | kill 单节点、网络分区、高延迟、磁盘满等。       |
| 观测   | 路由决策延迟、插件成功率、恢复时间。            |
| 自动化  | QE 长期不可用 → 切换缓存/静态权重/轮询等降级路径。 |
| CI   | 混沌套件**每周**或发布前运行。             |

**验收标准**：

- 任意**单点**故障下，路由决策可用性 **≥ 99.9%**，**P99 恢复 &lt; 10 s**（与 §3.3/§14.3 口径对齐可另行声明）。
- 降级期间核心推理错误率增量 **&lt; 0.1%**（约定负载）。

**责任角色**：R SRE + QE团队 / C 内核。

---

### 18.7 安全沙箱：社区插件强制隔离

**现状**：沙箱为可选项，未按等级强制。

**投产要求**：

- **社区**插件：Firecracker microVM 或 gVisor；**egress 默认拒绝**；仅允许连 ACI Host / 内核 Service Mesh 指定端口。
- **认证**：容器隔离 + 安全扫描；**官方**：策略另定，须最小特权。

**实施步骤**：

| 步骤             | 内容                                                   |
| -------------- | ---------------------------------------------------- |
| Plugin Manager | 按等级选择运行时（社区 → Firecracker；认证 → Docker；官方 → 特权策略最小化）。 |
| 网络             | NetworkPolicy / iptables；社区无外网。                      |
| 资源             | 社区默认限额（如 0.5C / 1GiB、无 GPU 直通，推理经内核 API）。            |
| 门禁             | Trivy 等扫描；认证加静态分析。                                   |

**验收标准**：

- 社区插件**无法**随意出网、**无法**读其他租户数据、**无法**耗尽主机资源（在约定攻击面下）。
- 高危漏洞插件**无法上架**。

**责任角色**：R 安全 / C 插件、平台。

---

### 18.8 文档与规范：从示例到 CI 强制检查

**现状**：多处为示例或建议。

**投产要求**：违反规范**合并阻断**。

**实施步骤**：

| 检查项  | 手段                                    |
| ---- | ------------------------------------- |
| 协议兼容 | buf breaking（或等价）对 proto **向后兼容**检查。  |
| 插件清单 | `plugin.yaml` 必填 requires / provides。 |
| 质量门槛 | 认证套件分数 ≥ 70（C 级）等规则。                  |
| 性能   | 见 §18.4。                              |
| 文档同步 | API 从 proto **代码生成**，与实现一致。           |

**验收标准**：新插件 PR **全部检查通过**方可合并。

**责任角色**：R 平台工程 / C 各组件 Owner。

---

## 19. 从当前到 GA 的里程碑路线图

下表为**工程化交付**视角的里程碑（可与 §17 季度路线图交叉对照）。

| 里程碑                  | 时间（建议）  | 关键交付                                                     |
| -------------------- | ------- | -------------------------------------------------------- |
| **M1** 核心内核 + ACI 稳定 | 第 1–2 月 | Resource Manager、Inference Engine、ACI Host（L1/L2）、基础 SDK |
| **M2** 质量引擎 MVP      | 第 3 月   | 静态评分、多源采集、路由权重、降级状态机                                     |
| **M3** 插件生态基础        | 第 4 月   | Plugin Manager、依赖求解器、沙箱、官方 workflow 插件                   |
| **M4** 自动化治理         | 第 5 月   | 归因原型、性能基准自动化、安全扫描门禁                                      |
| **M5** 混沌与高可用        | 第 6 月   | 混沌测试通过、QE Raft 生产就绪、降级验证                                 |
| **M6** GA 候选         | 第 7 月   | 完整文档、迁移工具、市场 MVP、种子客户验证                                  |

---

## 20. 从蓝图到可投产的关键跨越（总结）

v6.0 达到可投产，重点不在于继续堆叠架构概念，而在于把设计原则落实为：**可自动化检查**（性能、协议、依赖、安全）、**可复现测试**（基准、混沌）、**可操作流程**（仲裁、审计、经济约束）与**可运维闭环**（降级、归因、路由平滑）。

当 §18 所列工程护栏全部达到验收标准，v6.0 才能从「优秀的蓝图」转为「企业可放心部署」的发行版。

---

## 21. 附录

### A. 统一错误码（节选）

| 码   | 说明   | 处理     |
| --- | ---- | ------ |
| 200 | 成功   | -      |
| 400 | 参数错误 | 校验     |
| 408 | 超时   | 幂等重试   |
| 429 | 限流   | 退避     |
| 500 | 内部错误 | 熔断     |
| 503 | 不可用  | 切换副本   |
| 504 | 网关超时 | 链路排查   |
| 551 | 质量不足 | 切换高质插件 |

### B. 术语表

| 术语             | 定义                              |
| -------------- | ------------------------------- |
| ACI            | Agent Capability Interface      |
| Kernel         | 微内核：资源、推理、安全、插件生命周期             |
| Plugin         | 通过 ACI 交互的可插拔组件                 |
| Quality Engine | 评估与驱动引擎                         |
| MCP            | Model Context Protocol，ACI 对齐对象 |

### C. 参考文献（示例）

- Model Context Protocol 规范
- vLLM 生产部署指南
- Raft 共识
- gRPC 性能最佳实践

---

**文档结束。**


