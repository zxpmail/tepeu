# Kernel 层与用户空间、插件层的协作机制

AgentOS v6.0 采用微内核 + 用户空间服务 + 插件的三层架构。Kernel 层提供基础资源与安全能力，用户空间的 ACI Host 作为协议网关和路由中枢，插件层实现具体业务逻辑。三者通过标准化 gRPC/HTTP 接口 + 事件总线 + 服务发现协作，形成“内核稳、用户活、插件丰”的生态。

## 一、分层职责回顾

| 层级       | 组件                                      | 核心职责                                  | 运行环境             |
| -------- | --------------------------------------- | ------------------------------------- | ---------------- |
| 插件层      | 各类 ACI 插件（官方/认证/社区）                     | 实现具体工具、资源、会话、评估能力                     | 独立容器（沙箱隔离）       |
| 用户空间     | ACI Host（含 Registry）                    | 协议路由、能力发现、请求转发、质量评分缓存                 | 无状态服务副本（K8s Pod） |
| Kernel 层 | 8 个核心模块（RM, IE, QE, SB, PM, EB, AL, CC） | 资源管理、推理执行、质量评估、安全基座、插件生命周期、事件与审计、配置中心 | 高可用集群            |

## 二、协作全景图

```mermaid
flowchart TB
    subgraph Plugin Layer
        P1[Tool Plugin]
        P2[Resource Plugin]
        P3[Session Plugin]
    end

    subgraph User Space
        ACI[ACI Host<br/>+ Registry]
    end

    subgraph Kernel Layer
        RM[Resource Manager]
        IE[Inference Engine]
        QE[Quality Engine]
        SB[Security Base]
        PM[Plugin Manager]
        EB[Event Bus]
        AL[Audit Log]
        CC[Config Center]
    end

    Client[Client] --> ACI

    ACI -->|调用插件| P1
    ACI -->|调用插件| P2
    ACI -->|调用插件| P3
    P1 -->|上报指标| EB
    P2 -->|上报指标| EB
    P3 -->|上报指标| EB

    ACI -->|查询评分/路由| QE
    ACI -->|资源检查| RM
    ACI -->|审计| AL

    PM -->|安装/升级插件| P1
    PM -->|分配资源| RM
    PM -->|安全扫描| SB
    PM -->|事件| EB

    EB -->|消费指标| QE
    QE -->|更新评分| CC
    RM -->|读取调度策略| CC
    SB -->|读取安全策略| CC
    AL -->|写入审计| AL_DB[(Audit Storage)]
```

### 🏗️ 架构分层：三权分立

系统划分为三个同心圆层级，每一层都有明确的职责边界：

#### 1. 插件层 —— 能力的“雇佣兵”

* **组件**：Tool Plugin, Resource Plugin, Session Plugin
* **定位**：这是系统的**扩展边界**。它们运行在用户空间，是具体的业务逻辑实现者。
* **特点**：
  * **多样性**：可以是代码解释器、文件读取器、或者数据库连接器。
  * **被动性**：它们不主动发起核心调度，而是等待 ACI Host 的调用。
  * **可观测性**：它们唯一的“义务”是向内核上报指标（通过 EB）。

#### 2. 用户空间 —— 用户的“控制台”

* **组件**：ACI Host + Registry
* **定位**：这是用户与系统交互的**门面**。
* **特点**：
  * **聚合**：它聚合了所有插件的能力，对外提供统一的接口。
  * **路由**：它不再直接调用插件，而是依赖内核的 QE 和 RM 来做决策。
  * **注意**：这里的 `Registry` 更多是作为 Host 的一部分，负责维护本地可用的插件列表，但决策权已上交给内核。

#### 3. 内核层 —— 系统的“大脑与神经”

* **组件**：RM, IE, QE, SB, PM, EB, AL, CC
* **定位**：这是系统的**核心控制面**。
* **特点**：
  * **管控**：PM 负责生杀大权（安装/升级），SB 负责安检。
  * **调度**：RM 负责资源分配，QE 负责质量打分。
  * **记忆**：CC 存储策略，AL 存储历史。

### 🔄 核心数据流向解析

这张图揭示了三个关键的闭环流：

#### 1. 插件生命周期流 —— 由 PM 主导

* **路径**：`PM -> P1` (安装) & `PM -> RM` (分配资源) & `PM -> SB` (安全扫描)
* **解读**：插件不是随意加载的。PM 是守门人，它先让 SB 扫描安全性，再找 RM 申请资源，最后才允许插件启动。这确保了**“不安全不运行，无资源不启动”**。

#### 2. 运行时决策流 —— 由 QE 主导

* **路径**：`ACI -> QE` (查询评分) -> `ACI -> RM` (资源检查) -> `ACI -> P1` (调用)
* **解读**：当用户想调用一个工具时，ACI Host 不是盲选，而是先问 QE“哪个插件最快？”，再问 RM“还有资源吗？”，最后才调用 P1。这实现了**“基于质量的智能路由”**。

#### 3. 质量进化流 —— 由 EB 主导

* **路径**：`P1 -> EB` (上报指标) -> `QE` (消费指标) -> `CC` (更新评分) -> `RM` (读取策略)
* **解读**：这是系统的**自学习机制**。插件运行得越好（指标好），QE 给的评分越高（写入 CC），RM 下次就越倾向于给它分配资源。反之，表现差的插件会被自动降权。

## 三、关键协作流程

### 1. 插件注册与上线（Kernel ↔ 用户空间 ↔ 插件）

1. Plugin Manager（Kernel）通过安全扫描和资源分配后，启动插件容器。
2. 插件启动后，主动向 ACI Host 的 Registry 发送 Register 请求（携带能力元数据、端点地址）。
3. Registry 缓存插件信息，并通知 Quality Engine 创建初始评分。
4. Quality Engine 将初始评分写入 Config Center，并发布 `PluginOnline` 事件到 Event Bus。

### 2. 客户端请求路由（用户空间 -> Kernel -> 插件）

1. 客户端请求（如 `tools/call`）到达 ACI Host。
2. ACI Host 向 Quality Engine 查询匹配插件的实时评分和路由权重。
3. ACI Host 根据权重选择目标插件，同时向 RM 检查资源可用性（可选）。
4. ACI Host 将请求转发到插件实例。
5. 插件执行后返回结果，ACI Host 将执行指标（延迟、成功/失败）异步发送到 Event Bus。

### 3. 质量反馈闭环（插件 -> 用户空间 -> Kernel -> 用户空间）

1. 插件执行指标通过 Event Bus 被 Quality Engine 消费。
2. Quality Engine 聚合指标（滑动窗口），重新计算插件评分，并更新 Config Center。
3. Config Center 通过 Watch 机制推送评分变更给 ACI Host，ACI Host 更新本地路由缓存。
4. 若评分下降严重，Quality Engine 可触发 Plugin Manager 进行回滚或告警。

### 4. 资源动态调整（Kernel ↔ 用户空间）

1. Resource Manager 监听 Config Center 中插件质量等级变化。
2. 插件质量等级提升（如 C -> A）时，RM 可分配更高优先级资源（如专属 GPU 切片）。
3. 插件质量等级下降时，RM 可回收资源，必要时触发抢占。

### 5. 安全策略强制执行（Kernel -> 用户空间 -> 插件）

1. Security Base 从 Config Center 读取租户级安全策略（沙箱类型、网络白名单）。
2. Security Base 通过运行时机制动态调整插件容器隔离级别。
3. 插件越权访问时，SB 阻断并发布 `SecurityViolation` 事件，Event Bus 通知 Audit Log 记录，并可触发 PM 自动禁用插件。

### 6. 审计与可观测性（所有层 -> Kernel）

1. 各层关键操作（路由决策、插件生命周期、评分变更、安全事件）都通过 Event Bus 发送到 Audit Log。
2. Audit Log 提供统一查询 API，供合规审计和运维分析。

## 四、设计原则与隔离性

| 原则      | 说明                                                    |
| ------- | ----------------------------------------------------- |
| 内核无状态化  | Kernel 核心模块（RM、IE、QE）不持有插件实例会话数据；会话状态由 ACI Host 或插件管理 |
| 插件沙箱强隔离 | 插件层无法直接调用 Kernel 内部接口，必须通过 ACI Host 标准协议；SB 强制最小权限    |
| 异步事件主导  | 非关键路径（指标上报、审计、评分更新）全部异步化，避免阻塞主请求链路                    |
| 配置驱动行为  | Kernel 通过 Config Center 暴露策略，用户空间和插件行为由策略驱动而非硬编码      |

通过这种分层协作，AgentOS 实现了内核稳定、用户空间灵活、插件安全可扩展的架构目标，同时保证高性能和高可观测性。
